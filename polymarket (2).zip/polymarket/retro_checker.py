"""
Retro‑checker: повторно опрашивает Gamma API и Alchemy RPC для всех кошельков
с age_status='unknown' и обновляет их статус, если возраст удалось определить.

Запуск:
    python retro_checker.py
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import aiohttp
from dotenv import load_dotenv

# ─── Подключаем корень проекта ───────────────────────────────────────────────
_project_root = str(Path(__file__).resolve().parent)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

# ─── Импорты существующих классов ────────────────────────────────────────────
from database import AGE_CONFIRMED, AGE_UNKNOWN, Database, WalletRecord
from checker import GammaWalletAgeProvider, Web3WalletAgeProvider

# ─── Логирование ──────────────────────────────────────────────────────────────
LOG_DIR = Path(__file__).resolve().parent / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

formatter = logging.Formatter(
    "%(asctime)s [%(levelname)s] retro_checker: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

# File handler (always)
file_handler = logging.FileHandler(str(LOG_DIR / "retro_checker.log"), encoding="utf-8")
file_handler.setLevel(logging.DEBUG)
file_handler.setFormatter(formatter)

# Console handler
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(formatter)

logger = logging.getLogger("retro_checker")
logger.setLevel(logging.DEBUG)
logger.addHandler(file_handler)
logger.addHandler(console_handler)

# ─── Конфигурация ────────────────────────────────────────────────────────────
load_dotenv()

GAMMA_API_URL = os.getenv("GAMMA_API_URL", "https://gamma-api.polymarket.com")
ALCHEMY_RPC_URL = os.getenv("ALCHEMY_RPC_URL", "")
WALLET_MAX_AGE_HOURS = float(os.getenv("WALLET_MAX_AGE_HOURS", "48"))
DATABASE_PATH = os.getenv("DATABASE_PATH", "polymarket_scanner.duckdb")

# Rate‑limiting: не более 5 запросов к Alchemy в секунду
ALCHEMY_RPS = 5


class RetroChecker:
    """Перепроверяет unknown‑кошельки через Gamma → Alchemy."""

    def __init__(self) -> None:
        if not ALCHEMY_RPC_URL:
            logger.error("ALCHEMY_RPC_URL не задан — проверка через RPC невозможна!")
            sys.exit(1)

        self.db = Database(DATABASE_PATH)
        self.db.connect()
        self._session: Optional[aiohttp.ClientSession] = None

        # Статистика
        self.total_unknown = 0
        self.resolved = 0
        self.would_be_insider = 0

    async def run(self) -> None:
        """Основной цикл перепроверки."""
        async with aiohttp.ClientSession(
            headers={"User-Agent": "polymarket-scanner/1.0"}
        ) as session:
            self._session = session

            gamma_provider = GammaWalletAgeProvider(
                gamma_api_url=GAMMA_API_URL,
                session=session,
            )
            web3_provider = Web3WalletAgeProvider(
                rpc_url=ALCHEMY_RPC_URL,
                session=session,
                max_age_hours=WALLET_MAX_AGE_HOURS,
            )

            # Загружаем все unknown‑кошельки
            rows = self.db.conn.execute(
                """
                SELECT wallet_address, is_insider, created_at, first_seen, age_status
                FROM wallets_registry
                WHERE age_status = ?
                """,
                [AGE_UNKNOWN],
            ).fetchall()

            self.total_unknown = len(rows)
            logger.info(
                "Найдено кошельков с age_status='unknown': %d", self.total_unknown
            )

            if self.total_unknown == 0:
                logger.info("Нечего перепроверять — выходим.")
                self._print_stats()
                return

            wallets: list[WalletRecord] = [
                WalletRecord(
                    wallet_address=str(row[0]),
                    is_insider=bool(row[1]),
                    created_at=row[2],
                    first_seen=row[3],
                    age_status=str(row[4]) if row[4] else AGE_UNKNOWN,
                )
                for row in rows
            ]

            # Семафор для rate‑limiting Alchemy (5 RPS)
            alchemy_sem = asyncio.Semaphore(ALCHEMY_RPS)

            async def check_wallet(record: WalletRecord) -> None:
                """Проверить один кошелёк."""
                addr = record.wallet_address

                # 1. Сначала Gamma (дешёвый HTTP)
                created_at = await gamma_provider.get_wallet_created_at(addr)

                # 2. Если Gamma не дала — Alchemy (с rate‑limiting)
                if created_at is None:
                    async with alchemy_sem:
                        created_at = await web3_provider.get_wallet_created_at(addr)
                    # Небольшая задержка для соблюдения RPS
                    await asyncio.sleep(1.0 / ALCHEMY_RPS)

                if created_at is None:
                    # Не удалось определить — оставляем unknown
                    return

                # 3. Возраст определён — обновляем
                self.resolved += 1

                # Нормализуем таймзону
                if created_at.tzinfo is None:
                    created_at = created_at.replace(tzinfo=timezone.utc)

                # Проверяем: был бы кошелёк инсайдером на момент first_seen?
                updated_record = WalletRecord(
                    wallet_address=addr,
                    is_insider=False,  # placeholder — пересчитаем
                    created_at=created_at,
                    first_seen=record.first_seen,
                    age_status=AGE_CONFIRMED,
                )
                would_be = updated_record.would_have_been_insider(
                    max_age_hours=WALLET_MAX_AGE_HOURS
                )

                # Пересчитываем is_insider (текущий возраст)
                age_now = datetime.now(timezone.utc) - created_at
                is_insider_now = age_now.total_seconds() < WALLET_MAX_AGE_HOURS * 3600

                if would_be:
                    self.would_be_insider += 1

                # 4. Обновляем в БД
                self.db.conn.execute(
                    """
                    UPDATE wallets_registry
                    SET created_at = ?,
                        is_insider = ?,
                        age_status = ?
                    WHERE wallet_address = ?
                    """,
                    [created_at, is_insider_now, AGE_CONFIRMED, addr],
                )

                logger.info(
                    "RETRO: wallet=%s age_found=%s would_have_been_insider=%s is_insider_now=%s",
                    addr,
                    created_at.isoformat(),
                    would_be,
                    is_insider_now,
                )

            # Запускаем с прогресс‑счётчиком
            tasks = []
            for record in wallets:
                tasks.append(check_wallet(record))

            # Используем asyncio.gather со семафором на общий конкурентный доступ
            # (Alchemy уже лимитирован внутренним семафором; Gamma не лимитируем)
            done = 0
            start_time = time.monotonic()

            # Разбиваем на батчи по 50 для удобного вывода прогресса
            batch_size = 50
            for i in range(0, len(tasks), batch_size):
                batch = tasks[i : i + batch_size]
                await asyncio.gather(*batch)
                done += len(batch)
                elapsed = time.monotonic() - start_time
                pct = done / self.total_unknown * 100
                rps = done / elapsed if elapsed > 0 else 0
                logger.info(
                    "Прогресс: %d / %d (%.1f%%) | resolved=%d | would_be_insider=%d | %.1f wallets/s",
                    done,
                    self.total_unknown,
                    pct,
                    self.resolved,
                    self.would_be_insider,
                    rps,
                )

        self._print_stats()

    def _print_stats(self) -> None:
        """Вывести итоговую статистику."""
        print()
        print("═" * 60)
        print("          RETRO‑CHECKER: ИТОГОВАЯ СТАТИСТИКА")
        print("═" * 60)
        print(f"  Всего unknown:                 {self.total_unknown}")
        print(f"  Успешно разрешено (resolved):  {self.resolved}")
        print(f"  Из них были бы insiders:       {self.would_be_insider}")
        still_unknown = self.total_unknown - self.resolved
        print(f"  Осталось unknown:              {still_unknown}")
        print("═" * 60)
        print()

    def close(self) -> None:
        """Закрыть соединение с БД."""
        self.db.close()


def main() -> None:
    checker = RetroChecker()
    try:
        asyncio.run(checker.run())
    except KeyboardInterrupt:
        logger.warning("Прервано пользователем")
        sys.exit(1)
    except Exception:
        logger.exception("Критическая ошибка в retro_checker")
        sys.exit(1)
    finally:
        checker.close()

    # Exit code
    if checker.total_unknown > 0 and checker.resolved == 0 and checker.total_unknown > 0:
        # Пытались, но ничего не получилось — это не ошибка, просто нет данных
        pass

    logger.info("Retro‑checker завершён успешно.")


if __name__ == "__main__":
    main()
