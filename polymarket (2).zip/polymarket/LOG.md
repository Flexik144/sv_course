# 📋 LOG — История изменений проекта

> Каждое изменение должно иметь дату, автора, описание и инструкцию по откату.
> Формат: `YYYY-MM-DD HH:MM | Действие | Кто | Откат`

---

## 2026-06-26

| Время | Действие | Откат |
|-------|----------|-------|
| 01:49 | `database.py` — добавлена колонка `first_seen TIMESTAMP` (для всех кошельков) | `cp database.py.bak2 database.py && rm database.py.bak2` |
| 01:49 | `database.py` — `WalletRecord.first_seen`, `would_have_been_insider()` метод | `cp database.py.bak2 database.py && rm database.py.bak2` |
| 01:49 | `checker.py` — передача `first_seen=now()` при upsert | `cp checker.py.bak2 checker.py && rm checker.py.bak2` |
| 01:49 | `docs/backfill_first_seen.py` — скрипт миграции БД (backfill 7387 кошельков, все получили first_seen) | удалить файл |
| 01:58 | `retro_checker.py` — создан делегированным агентом. Перепроверяет unknown-кошельки через Gamma → Alchemy, обновляет статус в БД. Rate limit 5 RPS. | удалить файл |
| 01:58 | `README.md` — добавлена полная схема БД | откатить через git |
| 02:10 | `retro_checker.py` запущен — confirmed: 0 unknown в БД | — |
| 02:10 | `docs/inventory.py` — написан и запущен, показал полную статистику | удалить файл |
| 02:10 | `PLAN.md` — отмечен прогресс Фазы 1 (P0 ✅ P1 ✅ P2 ❌) | откатить через git |
| 02:10 | `docs/metrics.py` — написан и запущен. P2 решён ✅ | удалить файл |
| 02:10 | `PLAN.md` — P2 помечен ✅ | откатить через git |

## 2026-06-25

| Время | Действие | Откат |
|-------|----------|-------|
| 23:59 | Полный бэкап кода проекта (без БД и __pycache__) | `tar -xzf /c/hermes/polymarket_backup_20260625_235909.tar.gz -C /c/hermes/` |
| 23:59 | Создан `LOG.md` — файл истории изменений | Удалить файл |
| 23:59 | Создан `PLAN.md` — архитектурный план развития | Удалить файл |
| 23:59 | Создан `README.md` — описание проекта | Удалить файл |
| 23:59 | Созданы папки `docs/` и `logs/` | `rm -rf docs/ logs/` |
| 23:59 | `checker.py` — улучшено логгирование провайдеров, mystery-логгер, колбэк mystery | `cp checker.py.bak checker.py && rm checker.py.bak` |
| 23:59 | `main.py` — добавлен mystery-колбэк с полным контекстом сделки, отображение `age_status` на известных кошельках | `cp main.py.bak main.py && rm main.py.bak` |
| 23:59 | `database.py` — **Вариант B:** добавлена колонка `age_status` (`confirmed`/`unknown`), миграция + backfill | `cp database.py.bak database.py && rm database.py.bak` |
| 23:59 | `.gitignore` — добавлен `*.bak` | откатить вручную |

---

## Формат добавления новых записей

```markdown
## YYYY-MM-DD

| Время | Действие | Откат |
|-------|----------|-------|
| HH:MM | Краткое описание | Инструкция по откату |
| HH:MM | Следующее действие | ... |
```
