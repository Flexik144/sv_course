# 🕵️ Polymarket Insider Scanner

Асинхронный сканер для обнаружения потенциальных инсайдерских сделок
на [Polymarket](https://polymarket.com).

**Концепция:** Свежие кошельки (< 48 часов), совершающие крупные сделки (≥ $10,000),
могут указывать на инсайдерскую торговлю на прогнозных рынках.

## 🔧 Быстрый старт

```bash
cd C:\hermes\polymarket
pip install -r requirements.txt

# Настроить .env (скопировать .env.example, указать ALCHEMY_RPC_URL)
python main.py
```

## 🏗️ Архитектура

```
TradePoller (Data API, 1с) ─┐
                              ├─▶ asyncio.Queue ─▶ TradePipeline ─▶ WalletChecker ─▶ DuckDB
ShardedWS (6 шардов) ───────┘       │                    │                │
                                     │                    │                │
                              MarketDiscovery         TxReceiptEnricher   Gamma API
                              (топ-2000 рынков)        (Polygon RPC)      Alchemy RPC
```

**Два источника сделок:**
1. **Poll** — опрос Data API каждые N секунд (глобально, все рынки)
2. **WebSocket** — 6 шардов на топ-2000 рынков по объёму (можно отключить)

## 📁 Структура папки

```
polymarket/
├── main.py          # Точка входа, запуск всех компонентов
├── scanner.py       # Пул WS, Poller, Market Discovery, ParsedTrade
├── database.py      # DuckDB слой (wallets_registry + insider_trades)
├── pipeline.py      # Дедупликация + обогащение сделок
├── checker.py       # Проверка возраста кошелька (insider/not)
├── enricher.py      # On-chain обогащение через Polygon RPC
├── check_db.py      # Утилита для просмотра DuckDB
├── docs/            # Дополнительная документация
├── LOG.md           # История изменений проекта
├── PLAN.md          # План развития
├── .env             # Конфигурация и секреты
├── .env.example     # Шаблон .env
└── requirements.txt # Зависимости
```

## ⚙️ Основные настройки (`.env`)

| Параметр | Дефолт | Описание |
|---|---|---|
| `MIN_TRADE_VOLUME_USD` | 10000 | Мин. объём сделки |
| `WALLET_MAX_AGE_HOURS` | 48 | Макс. возраст "молодого" кошелька |
| `TRADE_POLL_INTERVAL_SEC` | 1 | Частота опроса Data API |
| `TRADE_POLL_LIMIT` | 10000 | Макс. сделок за один poll |
| `ENABLE_WS` | false | WebSocket-шарды (true/false) |
| `WS_SHARD_COUNT` | 6 | Количество WS-соединений |
| `ALCHEMY_RPC_URL` | — | **Обязателен** для on-chain проверки |

## 🗄️ Схема БД

### `wallets_registry`
| Колонка | Тип | Описание |
|---|---|---|
| `wallet_address` | VARCHAR PK | Адрес кошелька (lowercase) |
| `is_insider` | BOOLEAN | Признак молодого кошелька |
| `created_at` | TIMESTAMP | Время первой активности (1970-01-01 = unknown) |
| `first_seen` | TIMESTAMP | Когда сканер впервые обнаружил кошелёк |
| `age_status` | VARCHAR | `confirmed` / `unknown` |

### `insider_trades`
| Колонка | Тип | Описание |
|---|---|---|
| `trade_id` | VARCHAR PK | `{tx_hash}:{wallet}` |
| `wallet_address` | VARCHAR FK | Ссылка на `wallets_registry` |
| `market_id` | VARCHAR | ID рынка (conditionId) |
| `market_name` | VARCHAR | Название рынка |
| `volume_usd` | DOUBLE | Объём сделки |
| `timestamp` | TIMESTAMP | Время сделки |
