"""On-chain trade enrichment via Polygon transaction receipts."""

from __future__ import annotations

import logging
from typing import Any, Optional

import aiohttp

logger = logging.getLogger(__name__)

DEFAULT_HEADERS = {"User-Agent": "polymarket-scanner/1.0", "Content-Type": "application/json"}
ZERO_ADDRESS = "0x0000000000000000000000000000000000000000"
# ERC-20 / ERC-721 Transfer(address,address,uint256)
TRANSFER_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"


def topic_to_address(topic: str) -> Optional[str]:
    """Decode a 32-byte log topic to an EVM address."""
    if not topic or len(topic) < 42:
        return None
    addr = ("0x" + topic[-40:]).lower()
    if addr == ZERO_ADDRESS:
        return None
    return addr


class TxReceiptEnricher:
    """Extract participant wallet addresses from a Polygon transaction."""

    def __init__(self, rpc_url: str) -> None:
        self.rpc_url = rpc_url
        self._tx_cache: dict[str, list[str]] = {}

    async def _rpc(self, session: aiohttp.ClientSession, method: str, params: list[Any]) -> Any:
        payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        async with session.post(
            self.rpc_url,
            json=payload,
            headers=DEFAULT_HEADERS,
            timeout=aiohttp.ClientTimeout(total=20),
        ) as response:
            response.raise_for_status()
            body = await response.json()
        if body.get("error"):
            raise RuntimeError(body["error"])
        return body.get("result")

    async def get_participant_addresses(
        self,
        session: aiohttp.ClientSession,
        transaction_hash: str,
    ) -> list[str]:
        """Return unique wallet addresses involved in ``transaction_hash``."""
        if not self.rpc_url or not transaction_hash:
            return []

        tx_hash = transaction_hash.lower()
        if not tx_hash.startswith("0x"):
            tx_hash = f"0x{tx_hash}"

        if tx_hash in self._tx_cache:
            return self._tx_cache[tx_hash]

        addresses: set[str] = set()
        try:
            tx = await self._rpc(session, "eth_getTransactionByHash", [tx_hash])
            if tx:
                for field in ("from", "to"):
                    value = tx.get(field)
                    if value and value.lower() != ZERO_ADDRESS:
                        addresses.add(value.lower())

            receipt = await self._rpc(session, "eth_getTransactionReceipt", [tx_hash])
            if receipt:
                for log in receipt.get("logs", []):
                    topics = log.get("topics") or []
                    if topics and topics[0].lower() == TRANSFER_TOPIC:
                        for topic in topics[1:3]:
                            addr = topic_to_address(str(topic))
                            if addr:
                                addresses.add(addr)
                    else:
                        for topic in topics[1:]:
                            addr = topic_to_address(str(topic))
                            if addr:
                                addresses.add(addr)
        except Exception:
            logger.exception("Failed to parse transaction %s", tx_hash)
            return []

        result = sorted(addresses)
        self._tx_cache[tx_hash] = result
        if len(self._tx_cache) > 5000:
            self._tx_cache.clear()
        return result
