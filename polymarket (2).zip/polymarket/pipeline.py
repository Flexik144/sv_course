"""Shared trade deduplication and enrichment pipeline."""

from __future__ import annotations

import asyncio
import logging
from typing import Awaitable, Callable, Optional, Set

import aiohttp

from enricher import TxReceiptEnricher
from scanner import ParsedTrade, PollFeedback, TradeEnricher

logger = logging.getLogger(__name__)

OnTradeCallback = Callable[[ParsedTrade, str], Awaitable[None]]


class TradePipeline:
    """
    Fail-fast funnel with dedup:
    volume filter -> optional on-chain participants -> callback.
    """

    def __init__(
        self,
        min_volume_usd: float,
        tx_enricher: TxReceiptEnricher,
        data_enricher: TradeEnricher,
        on_trade: OnTradeCallback,
        feedback: Optional[PollFeedback] = None,
    ) -> None:
        self.min_volume_usd = min_volume_usd
        self.tx_enricher = tx_enricher
        self.data_enricher = data_enricher
        self.on_trade = on_trade
        self.feedback = feedback
        self._seen_tx: Set[str] = set()
        self._seen_keys: Set[str] = set()

    def _dedup_key(self, trade: ParsedTrade) -> str:
        if trade.transaction_hash:
            return trade.transaction_hash.lower()
        return trade.trade_id

    def is_duplicate(self, trade: ParsedTrade) -> bool:
        key = self._dedup_key(trade)
        if key in self._seen_keys:
            return True
        if trade.transaction_hash:
            tx = trade.transaction_hash.lower()
            if tx in self._seen_tx:
                return True
        return False

    def mark_seen(self, trade: ParsedTrade) -> None:
        self._seen_keys.add(self._dedup_key(trade))
        if trade.transaction_hash:
            self._seen_tx.add(trade.transaction_hash.lower())
        if len(self._seen_keys) > 50_000:
            self._seen_keys.clear()
            self._seen_tx.clear()

    async def enrich_participants(
        self,
        session: aiohttp.ClientSession,
        trade: ParsedTrade,
    ) -> ParsedTrade:
        """Add wallets from Data API match and on-chain receipt."""
        if not trade.participant_wallets and trade.market_id:
            trade = await self.data_enricher.enrich(session, trade)

        if trade.transaction_hash and trade.volume_usd >= self.min_volume_usd:
            on_chain = await self.tx_enricher.get_participant_addresses(
                session, trade.transaction_hash
            )
            if on_chain:
                return trade.with_addresses(on_chain)

        return trade

    async def process(
        self,
        session: aiohttp.ClientSession,
        trade: ParsedTrade,
        source: str,
    ) -> None:
        if trade.volume_usd < self.min_volume_usd:
            logger.debug(
                "[%s] Filtered by volume: $%.2f < $%.2f",
                source,
                trade.volume_usd,
                self.min_volume_usd,
            )
            return
        if self.is_duplicate(trade):
            logger.debug("[%s] Duplicate trade: %s", source, trade.trade_id)
            return

        trade = await self.enrich_participants(session, trade)
        if not trade.participant_wallets:
            logger.debug(
                "[%s] No wallets for trade market=%s volume=$%.2f",
                source,
                trade.market_id,
                trade.volume_usd,
            )
            return

        logger.info(
            "[%s] Processing trade: market=%s volume=$%.2f wallets=%d",
            source,
            trade.market_id[:18] + "...",
            trade.volume_usd,
            len(trade.participant_wallets),
        )
        self.mark_seen(trade)
        if self.feedback is not None:
            self.feedback.new_trades += 1
        await self.on_trade(trade, source)
