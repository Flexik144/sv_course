"""Entry point: hybrid poll + sharded WebSocket insider scanner."""

from __future__ import annotations

import asyncio
import logging
import os
from typing import Any, Set

import aiohttp
from dotenv import load_dotenv

from checker import GammaWalletAgeProvider, WalletChecker, Web3WalletAgeProvider
from database import Database
from enricher import TxReceiptEnricher
from pipeline import TradePipeline
from scanner import (
    MarketDiscovery,
    ParsedTrade,
    PollFeedback,
    ShardedWebSocketPool,
    TradeEnricher,
    TradePoller,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


class InsiderScanner:
    """Hybrid: Data API poll (global) + sharded WS (top markets)."""

    def __init__(self) -> None:
        load_dotenv()
        self.min_volume = float(os.getenv("MIN_TRADE_VOLUME_USD", "10000"))
        self.max_age_hours = float(os.getenv("WALLET_MAX_AGE_HOURS", "48"))
        self.db = Database(os.getenv("DATABASE_PATH", "polymarket_scanner.duckdb"))
        self.known_wallets: Set[str] = set()
        self.checker: WalletChecker | None = None
        self._wallet_sem = asyncio.Semaphore(
            int(os.getenv("WALLET_CHECK_CONCURRENCY", "4"))
        )
        self._trade_queue: asyncio.Queue[tuple[ParsedTrade, str]] = asyncio.Queue(
            maxsize=int(os.getenv("TRADE_QUEUE_SIZE", "50000"))
        )

        gamma_url = os.getenv("GAMMA_API_URL", "https://gamma-api.polymarket.com")
        data_url = os.getenv("DATA_API_URL", "https://data-api.polymarket.com")

        self.discovery = MarketDiscovery(
            gamma_api_url=gamma_url,
            interval_sec=float(os.getenv("MARKET_DISCOVERY_INTERVAL_SEC", "180")),
            max_markets=int(os.getenv("MAX_WS_MARKETS", "2000")),
        )
        self.poll_feedback = PollFeedback()
        self.poller = TradePoller(
            data_api_url=data_url,
            interval_sec=float(os.getenv("TRADE_POLL_INTERVAL_SEC", "4")),
            poll_limit=int(os.getenv("TRADE_POLL_LIMIT", "100")),
            min_interval_sec=float(os.getenv("MIN_POLL_INTERVAL_SEC", "0.5")),
            max_interval_sec=float(os.getenv("MAX_POLL_INTERVAL_SEC", "30.0")),
            min_poll_limit=int(os.getenv("MIN_POLL_LIMIT", "100")),
            max_poll_limit=int(os.getenv("MAX_POLL_LIMIT", "50000")),
            feedback=self.poll_feedback,
        )
        self.ws_pool: ShardedWebSocketPool | None = None
        self.pipeline: TradePipeline | None = None
        self._session: aiohttp.ClientSession | None = None
        # Последняя обрабатываемая сделка — для mystery-логгирования
        self._mystery_trade_context: tuple[Any, str] | None = None

    async def startup(self) -> None:
        self.db.connect()
        self.known_wallets = self.db.load_known_wallets()
        logger.info("Loaded %d known wallets from registry", len(self.known_wallets))

    async def _pipeline_trade(self, trade: ParsedTrade, source: str) -> None:
        assert self.pipeline is not None
        # Pipeline callback after enrichment
        await self._handle_trade(trade, source)

    async def _ingest_trade(self, trade: ParsedTrade, source: str) -> None:
        """Entry from poller or WS — runs through shared pipeline."""
        if self.pipeline is None:
            return
        session = self._session
        if session is None:
            return
        await self.pipeline.process(session, trade, source)

    async def _handle_trade(self, trade: ParsedTrade, source: str) -> None:
        for wallet in trade.participant_wallets:
            normalized = self.db.normalize_address(wallet)

            if normalized in self.known_wallets:
                record = self.db.get_wallet(normalized)
                if record and record.is_insider:
                    await self._log_insider_trade(trade, normalized, f"[{source}] known insider")
                elif record and record.is_age_unknown:
                    logger.debug("[%s] Known unknown-age wallet: %s (age not resolved, skipping)", source, normalized)
                continue

            if self.checker is None:
                continue

            # Сохраняем контекст сделки для mystery-логгирования
            self._mystery_trade_context = (trade, source)

            async with self._wallet_sem:
                is_insider = await self.checker.process_new_wallet(normalized)
            if is_insider:
                await self._log_insider_trade(trade, normalized, f"[{source}] new insider")

    async def _log_insider_trade(self, trade: ParsedTrade, wallet: str, label: str) -> None:
        market_name = trade.market_name or None

        self.db.insert_insider_trade(
            trade_id=f"{trade.trade_id}:{wallet}",
            wallet_address=wallet,
            market_id=trade.market_id,
            market_name=market_name,
            volume_usd=trade.volume_usd,
            timestamp=trade.timestamp,
        )
        logger.info(
            "%s: wallet=%s volume=$%.2f wallets_in_tx=%d market=%s",
            label,
            wallet,
            trade.volume_usd,
            len(trade.participant_wallets),
            market_name or trade.market_id[:18] + "...",
        )

    async def on_markets_updated(self, asset_ids: Set[str]) -> None:
        if self.ws_pool is not None:
            await self.ws_pool.update_subscriptions(asset_ids)

    async def _trade_queue_consumer(self) -> None:
        """Process trades from the queue."""
        logger.info("Trade queue consumer started")
        while True:
            try:
                trade, source = await self._trade_queue.get()
                await self._ingest_trade(trade, source)
                self._trade_queue.task_done()
            except Exception:
                logger.exception("Trade queue consumer failed")
                await asyncio.sleep(1)

    async def run(self) -> None:
        await self.startup()
        enable_ws = os.getenv("ENABLE_WS", "true").lower() in ("1", "true", "yes")

        async with aiohttp.ClientSession(headers={"User-Agent": "polymarket-scanner/1.0"}) as session:
            self._session = session

            gamma_provider = GammaWalletAgeProvider(
                gamma_api_url=os.getenv("GAMMA_API_URL", "https://gamma-api.polymarket.com"),
                session=session,
            )
            web3_provider = Web3WalletAgeProvider(
                rpc_url=os.getenv("ALCHEMY_RPC_URL", ""),
                session=session,
                max_age_hours=self.max_age_hours,
            )

            async def _on_mystery_wallet(wallet: str) -> None:
                """Вызывается, когда возраст кошелька не удалось определить."""
                trade, source = getattr(self, "_mystery_trade_context", (None, None))
                if trade is not None:
                    logger.warning(
                        "[MYSTERY] Full trade context for wallet %s:\n"
                        "  source=%s trade_id=%s market_id=%s market_name=%s\n"
                        "  volume=$%.2f price=$%.2f size=%.4f timestamp=%s\n"
                        "  maker=%s taker=%s proxy=%s tx_hash=%s\n"
                        "  extra_addresses=%s",
                        wallet,
                        source,
                        trade.trade_id,
                        trade.market_id,
                        trade.market_name or "(no name)",
                        trade.volume_usd,
                        trade.price,
                        trade.size,
                        trade.timestamp.isoformat(),
                        trade.maker,
                        trade.taker,
                        trade.proxy_wallet,
                        trade.transaction_hash,
                        list(trade.extra_addresses),
                    )
                else:
                    logger.warning(
                        "[MYSTERY] No trade context for wallet %s",
                        wallet,
                    )

            self.checker = WalletChecker(
                db=self.db,
                known_wallets=self.known_wallets,
                primary_provider=gamma_provider,
                fallback_provider=web3_provider,
                max_age_hours=self.max_age_hours,
                on_mystery_wallet=_on_mystery_wallet,
            )

            tx_enricher = TxReceiptEnricher(rpc_url=os.getenv("ALCHEMY_RPC_URL", ""))
            data_enricher = TradeEnricher(
                data_api_url=os.getenv("DATA_API_URL", "https://data-api.polymarket.com"),
            )
            self.pipeline = TradePipeline(
                min_volume_usd=self.min_volume,
                tx_enricher=tx_enricher,
                data_enricher=data_enricher,
                on_trade=self._pipeline_trade,
                feedback=self.poll_feedback,
            )

            tasks: list[asyncio.Task] = []

            # Start queue consumer
            consumer_task = asyncio.create_task(self._trade_queue_consumer())
            tasks.append(consumer_task)
            logger.info("Trade queue consumer started")

            # Start poller with queue
            poll_task = asyncio.create_task(
                self.poller.run(session, self._trade_queue, "poll")
            )
            tasks.append(poll_task)
            logger.info(
                "Trade poller started (interval=%ss, limit=%s)",
                self.poller.interval_sec,
                self.poller.poll_limit,
            )

            if enable_ws:
                logger.info("Running market discovery for WebSocket shards...")
                initial_assets = await self.discovery.fetch_top_asset_ids(session)
                self.discovery.active_asset_ids = initial_assets

                async def ws_handler(trade: ParsedTrade) -> None:
                    try:
                        self._trade_queue.put_nowait((trade, "ws"))
                    except asyncio.QueueFull:
                        logger.warning("Trade queue full, dropping WS trade")

                self.ws_pool = ShardedWebSocketPool(
                    ws_url=os.getenv(
                        "CLOB_WS_URL",
                        "wss://ws-subscriptions.clob.polymarket.com/ws/market",
                    ),
                    shard_count=int(os.getenv("WS_SHARD_COUNT", "6")),
                    min_volume_usd=self.min_volume,
                    on_trade=ws_handler,
                )
                await self.ws_pool.update_subscriptions(initial_assets)

                tasks.append(asyncio.create_task(self.ws_pool.run()))
                tasks.append(
                    asyncio.create_task(self.discovery.run(session, self.on_markets_updated))
                )
                logger.info(
                    "WebSocket pool: %d shards, %d asset IDs",
                    self.ws_pool.shard_count,
                    len(initial_assets),
                )
            else:
                logger.info("WebSocket disabled (ENABLE_WS=false)")

            try:
                await asyncio.gather(*tasks)
            finally:
                self.poller.stop()
                if self.ws_pool is not None:
                    self.ws_pool.stop()
                self.db.close()
                self._session = None


def main() -> None:
    scanner = InsiderScanner()
    try:
        asyncio.run(scanner.run())
    except KeyboardInterrupt:
        logger.info("Scanner stopped by user")


if __name__ == "__main__":
    main()
