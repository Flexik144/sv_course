import duckdb

conn = duckdb.connect('polymarket_scanner.duckdb')

print('=== TABLES ===')
tables = conn.execute('SHOW TABLES').fetchall()
print(tables)

print('\n=== WALLETS_REGISTRY ===')
wallets = conn.execute('SELECT * FROM wallets_registry').fetchall()
print(f'Total wallets: {len(wallets)}')
for w in wallets:
    print(w)

print('\n=== INSIDER_TRADES ===')
trades = conn.execute('SELECT * FROM insider_trades').fetchall()
print(f'Total insider trades: {len(trades)}')
for t in trades:
    print(t)

print('\n=== INSIDER_TRADES WITH MARKET NAMES ===')
trades_with_names = conn.execute('SELECT trade_id, wallet_address, market_id, market_name, volume_usd, timestamp FROM insider_trades ORDER BY timestamp DESC').fetchall()
print(f'Total insider trades: {len(trades_with_names)}')
for t in trades_with_names:
    print(f"Trade: {t[0][:30]}... | Wallet: {t[1]} | Market: {t[3] or t[2][:20] + '...'} | Volume: ${t[4]:.2f} | Time: {t[5]}")

print('\n=== DUPLICATE DETAILS FOR 0x966465... ===')
rows = conn.execute('SELECT * FROM insider_trades WHERE wallet_address = \'0x966465d896a84cf3b6bc1695ca1f26c3239b3868\' ORDER BY timestamp').fetchall()
for r in rows:
    print(r)
