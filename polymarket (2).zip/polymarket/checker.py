"""Wallet age verification via Polygon RPC or Polymarket Gamma API fallback."""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Optional, Protocol

import aiohttp

logger = logging.getLogger(__name__)
# Отдельный логгер для "загадочных" кошельков — пишет максимально подробно
mystery_logger = logging.getLogger("mystery_wallets")
mystery_handler_added = False


def _ensure_mystery_handler() -> None:
    """Добавляет файловый handler для mystery-логов, если ещё не добавлен."""
    global mystery_handler_added
    if mystery_handler_added:
        return
    from pathlib import Path

    log_dir = Path(__file__).resolve().parent / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    handler = logging.FileHandler(str(log_dir / "mystery_wallets.log"), encoding="utf-8")
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s [%(levelname)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )
    mystery_logger.addHandler(handler)
    mystery_logger.setLevel(logging.DEBUG)
    mystery_handler_added = True

DEFAULT_HEADERS = {"User-Agent": "polymarket-scanner/1.0", "Content-Type": "application/json"}
TRANSFER_CATEGORIES = ["external", "erc20", "erc721", "erc1155"]


class WalletAgeProvider(Protocol):
    """Protocol for swappable wallet-age lookup backends."""

    async def get_wallet_created_at(self, wallet_address: str) -> Optional[datetime]:
        """Return the wallet's first-activity timestamp, or ``None`` if unknown."""
        ...


class Web3WalletAgeProvider:
    """Query Polygon via Alchemy ``alchemy_getAssetTransfers`` for first activity."""

    def __init__(
        self,
        rpc_url: str,
        session: aiohttp.ClientSession,
        max_age_hours: float = 48.0,
    ) -> None:
        self.rpc_url = rpc_url
        self.session = session
        self.max_age_hours = max_age_hours

    async def get_wallet_created_at(self, wallet_address: str) -> Optional[datetime]:
        """Fetch earliest on-chain transfer involving ``wallet_address``."""
        if not self.rpc_url:
            logger.error("Alchemy: ALCHEMY_RPC_URL is not configured — cannot check on-chain age")
            return None

        address = wallet_address.strip().lower()
        incoming = await self._fetch_earliest_transfer(address, direction="to")
        outgoing = await self._fetch_earliest_transfer(address, direction="from")

        candidates = [ts for ts in (incoming, outgoing) if ts is not None]
        if not candidates:
            logger.debug("Alchemy: no transfers found for %s (incoming=empty, outgoing=empty)", address)
            return None
        earliest = min(candidates)
        logger.debug("Alchemy: earliest transfer for %s is %s", address, earliest.isoformat())
        return earliest

    async def _fetch_earliest_transfer(
        self,
        address: str,
        direction: str,
    ) -> Optional[datetime]:
        params: dict[str, Any] = {
            "fromBlock": "0x0",
            "toBlock": "latest",
            "category": TRANSFER_CATEGORIES,
            "maxCount": "0x1",
            "order": "asc",
            "withMetadata": True,
        }
        if direction == "to":
            params["toAddress"] = address
        else:
            params["fromAddress"] = address

        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "alchemy_getAssetTransfers",
            "params": [params],
        }

        try:
            async with self.session.post(
                self.rpc_url,
                json=payload,
                headers=DEFAULT_HEADERS,
                timeout=aiohttp.ClientTimeout(total=20),
            ) as response:
                response.raise_for_status()
                body = await response.json()
        except asyncio.TimeoutError:
            logger.warning("Alchemy: timeout fetching transfers for %s (%s)", address, direction)
            return None
        except aiohttp.ClientResponseError as exc:
            logger.warning(
                "Alchemy: HTTP %d for %s (%s): %s",
                exc.status, address, direction, exc.message,
            )
            return None
        except json.JSONDecodeError as exc:
            logger.warning("Alchemy: invalid JSON for %s (%s): %s", address, direction, exc)
            return None
        except Exception:
            logger.exception("Alchemy: unexpected error for %s (%s)", address, direction)
            return None

        if body.get("error"):
            logger.warning(
                "Alchemy: RPC error for %s (%s): %s",
                address, direction, body["error"],
            )
            return None

        transfers = body.get("result", {}).get("transfers", [])
        if not transfers:
            logger.debug("Alchemy: no transfers in result for %s (%s)", address, direction)
            return None

        metadata = transfers[0].get("metadata") or {}
        block_ts = metadata.get("blockTimestamp")
        if not block_ts:
            logger.debug("Alchemy: transfer found for %s (%s) but no blockTimestamp", address, direction)
            return None

        return datetime.fromisoformat(block_ts.replace("Z", "+00:00"))

    def is_insider(self, created_at: datetime) -> bool:
        """Return True if wallet is younger than ``max_age_hours``."""
        age = datetime.now(timezone.utc) - created_at.replace(tzinfo=timezone.utc)
        return age.total_seconds() < self.max_age_hours * 3600


class GammaWalletAgeProvider:
    """Fallback: use Polymarket Gamma API profile ``createdAt`` when available."""

    def __init__(self, gamma_api_url: str, session: aiohttp.ClientSession) -> None:
        self.gamma_api_url = gamma_api_url.rstrip("/")
        self.session = session

    async def get_wallet_created_at(self, wallet_address: str) -> Optional[datetime]:
        """Fetch profile creation time from Gamma public-profile endpoint."""
        address = wallet_address.strip().lower()
        try:
            async with self.session.get(
                f"{self.gamma_api_url}/public-profile",
                params={"address": address},
                headers={"User-Agent": "polymarket-scanner/1.0"},
                timeout=aiohttp.ClientTimeout(total=15),
            ) as response:
                if response.status == 404:
                    logger.debug("Gamma: no profile for wallet %s (404)", address)
                    return None
                response.raise_for_status()
                profile: dict[str, Any] = await response.json()
        except asyncio.TimeoutError:
            logger.warning("Gamma: timeout fetching profile for %s", address)
            return None
        except aiohttp.ClientResponseError as exc:
            logger.warning(
                "Gamma: HTTP %d for wallet %s: %s",
                exc.status, address, exc.message,
            )
            return None
        except json.JSONDecodeError as exc:
            logger.warning("Gamma: invalid JSON for wallet %s: %s", address, exc)
            return None
        except Exception:
            logger.exception("Gamma: unexpected error for wallet %s", address)
            return None

        created_raw = profile.get("createdAt")
        if not created_raw:
            logger.debug("Gamma: profile found for %s but no createdAt field", address)
            return None

        return datetime.fromisoformat(str(created_raw).replace("Z", "+00:00"))


class WalletChecker:
    """Consumer: classify new wallets and persist results."""

    def __init__(
        self,
        db,
        known_wallets: set[str],
        primary_provider: WalletAgeProvider,
        max_age_hours: float = 48.0,
        fallback_provider: Optional[WalletAgeProvider] = None,
        on_mystery_wallet: Optional[Callable[[str], Awaitable[None]]] = None,
    ) -> None:
        self.db = db
        self.known_wallets = known_wallets
        self.primary_provider = primary_provider
        self.fallback_provider = fallback_provider
        self.max_age_hours = max_age_hours
        self._mystery_logged: set[str] = set()
        # Колбэк: вызывается, когда возраст кошелька не удалось определить
        self.on_mystery_wallet = on_mystery_wallet
        _ensure_mystery_handler()

    def _is_insider(self, created_at: datetime) -> bool:
        age = datetime.now(timezone.utc) - created_at.replace(tzinfo=timezone.utc)
        return age.total_seconds() < self.max_age_hours * 3600

    async def classify_wallet(self, wallet_address: str) -> tuple[bool, datetime, str]:
        """
        Determine whether ``wallet_address`` is an insider (created within threshold).

        Returns:
            Tuple of ``(is_insider, created_at, age_status)``.
              - age_status: ``"confirmed"`` if age was resolved, ``"unknown"`` if both providers failed.
        """
        logger.info("Checking wallet age: %s", wallet_address)

        # Собираем причины отказа провайдеров для mystery-лога
        gamma_error = None
        alchemy_error = None

        # Gamma (cheap HTTP) first
        try:
            created_at = await self.primary_provider.get_wallet_created_at(wallet_address)
        except Exception as exc:
            created_at = None
            gamma_error = str(exc)
            logger.exception("Gamma: exception for %s", wallet_address)
        if created_at is not None:
            logger.info("Wallet age found via Gamma API: %s", created_at.isoformat())
        elif gamma_error is None:
            gamma_error = "returned None (no profile or no createdAt)"

        # Alchemy (on-chain RPC) as fallback
        if created_at is None and self.fallback_provider is not None:
            logger.info("Gamma API failed, trying Alchemy RPC fallback")
            try:
                created_at = await self.fallback_provider.get_wallet_created_at(wallet_address)
            except Exception as exc:
                alchemy_error = str(exc)
                logger.exception("Alchemy: exception for %s", wallet_address)
            if created_at is not None:
                logger.info("Wallet age found via Alchemy RPC: %s", created_at.isoformat())
            elif alchemy_error is None:
                alchemy_error = "returned None (no transfers found)"

        if created_at is None:
            logger.warning(
                "Could not resolve age for wallet %s; treating as non-insider "
                "(Gamma: %s, Alchemy: %s)",
                wallet_address,
                gamma_error or "N/A",
                alchemy_error or "N/A (fallback disabled)",
            )
            # Mystery wallet — пишем в отдельный лог с полным контекстом
            if wallet_address not in self._mystery_logged:
                self._mystery_logged.add(wallet_address)
                _ensure_mystery_handler()
                mystery_logger.warning(
                    "MYSTERY_WALLET | address=%s | gamma_error=%s | alchemy_error=%s",
                    wallet_address,
                    gamma_error or "N/A",
                    alchemy_error or "N/A (fallback disabled)",
                )
            # Use a very old date to ensure wallet is not classified as insider
            created_at = datetime(1970, 1, 1, tzinfo=timezone.utc)
            age_status = "unknown"
        else:
            age_status = "confirmed"

        is_insider = self._is_insider(created_at)
        logger.info(
            "Wallet %s age check: insider=%s (max_age=%s hours, created_at=%s, age_status=%s)",
            wallet_address,
            is_insider,
            self.max_age_hours,
            created_at.isoformat(),
            age_status,
        )
        return is_insider, created_at, age_status

    async def process_new_wallet(self, wallet_address: str) -> bool:
        """
        Check a new high-volume wallet, persist to DB, and update cache.

        Returns:
            True if wallet is classified as insider.
        """
        is_insider, created_at, age_status = await self.classify_wallet(wallet_address)
        normalized = self.db.normalize_address(wallet_address)
        self.db.upsert_wallet(
            normalized, is_insider, created_at,
            age_status=age_status,
            first_seen=datetime.now(timezone.utc),
        )
        self.known_wallets.add(normalized)
        if age_status == "unknown":
            logger.warning(
                "MYSTERY WALLET persisted: %s → insider=False (age unknown, 1970 fallback). "
                "Check logs/mystery_wallets.log for details.",
                normalized,
            )
            if self.on_mystery_wallet is not None:
                try:
                    await self.on_mystery_wallet(normalized)
                except Exception:
                    logger.exception("Mystery wallet callback failed for %s", normalized)
        else:
            logger.info(
                "Wallet classified: %s insider=%s created_at=%s age_status=%s",
                normalized,
                is_insider,
                created_at.isoformat(),
                age_status,
            )
        return is_insider
