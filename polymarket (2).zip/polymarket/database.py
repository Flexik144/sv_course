"""DuckDB persistence layer for wallet registry and insider trades."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import duckdb


AGE_CONFIRMED = "confirmed"
AGE_UNKNOWN = "unknown"


@dataclass(frozen=True)
class WalletRecord:
    """Row from ``wallets_registry``."""

    wallet_address: str
    is_insider: bool
    created_at: datetime
    first_seen: datetime
    age_status: str = AGE_CONFIRMED

    @property
    def is_age_unknown(self) -> bool:
        """True if the wallet's age could not be determined (neither Gamma nor RPC returned data)."""
        return self.age_status == AGE_UNKNOWN

    def would_have_been_insider(self, max_age_hours: float = 48.0) -> bool | None:
        """
        If the wallet's age was later resolved, was it young enough to be an insider
        at the time it was *first seen*?
        
        Returns:
            True  → would have been insider if we knew its age at discovery
            False → was already old when discovered
            None  → age still unknown (created_at is still 1970)
        """
        if self.created_at.year == 1970:
            return None  # age still unresolved
        age_at_discovery = self.first_seen - self.created_at.replace(tzinfo=self.first_seen.tzinfo)
        return age_at_discovery.total_seconds() < max_age_hours * 3600


@dataclass(frozen=True)
class InsiderTradeRecord:
    """Row from ``insider_trades``."""

    trade_id: str
    wallet_address: str
    market_id: str
    volume_usd: float
    timestamp: datetime


class Database:
    """Async-friendly DuckDB wrapper (sync I/O; call via ``asyncio.to_thread``)."""

    def __init__(self, db_path: str | Path = "polymarket_scanner.duckdb") -> None:
        self.db_path = Path(db_path)
        self._conn: Optional[duckdb.DuckDBPyConnection] = None

    @property
    def conn(self) -> duckdb.DuckDBPyConnection:
        if self._conn is None:
            raise RuntimeError("Database is not connected. Call connect() first.")
        return self._conn

    def connect(self) -> None:
        """Open DuckDB connection and ensure schema exists."""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            self._conn = duckdb.connect(str(self.db_path))
            self.init_schema()
        except Exception as e:
            raise RuntimeError(f"Failed to connect to database at {self.db_path}: {e}")

    def close(self) -> None:
        """Close the DuckDB connection."""
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def init_schema(self) -> None:
        """Create tables and indexes if they do not exist."""
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS wallets_registry (
                wallet_address VARCHAR PRIMARY KEY,
                is_insider     BOOLEAN NOT NULL,
                created_at     TIMESTAMP NOT NULL,
                first_seen     TIMESTAMP NOT NULL DEFAULT now(),
                age_status     VARCHAR NOT NULL DEFAULT 'confirmed'
            );

            CREATE TABLE IF NOT EXISTS insider_trades (
                trade_id       VARCHAR PRIMARY KEY,
                wallet_address VARCHAR NOT NULL,
                market_id      VARCHAR NOT NULL,
                market_name    VARCHAR,
                volume_usd     DOUBLE NOT NULL,
                timestamp      TIMESTAMP NOT NULL,
                FOREIGN KEY (wallet_address) REFERENCES wallets_registry(wallet_address)
            );

            CREATE INDEX IF NOT EXISTS idx_insider_trades_wallet
                ON insider_trades(wallet_address);

            CREATE INDEX IF NOT EXISTS idx_insider_trades_timestamp
                ON insider_trades(timestamp);
            """
        )
        # Add market_name column if it doesn't exist (for existing databases)
        try:
            self.conn.execute(
                "ALTER TABLE insider_trades ADD COLUMN IF NOT EXISTS market_name VARCHAR"
            )
        except Exception:
            pass  # Column might already exist

        # Add age_status column if it doesn't exist (for existing databases)
        try:
            self.conn.execute(
                "ALTER TABLE wallets_registry ADD COLUMN IF NOT EXISTS age_status VARCHAR"
            )
            self.conn.execute(
                "UPDATE wallets_registry SET age_status = 'confirmed' WHERE age_status IS NULL"
            )
        except Exception:
            pass  # Column might already exist

        # Add first_seen column if it doesn't exist (for existing databases)
        try:
            self.conn.execute(
                "ALTER TABLE wallets_registry ADD COLUMN IF NOT EXISTS first_seen TIMESTAMP"
            )
            self.conn.execute(
                "UPDATE wallets_registry SET first_seen = created_at WHERE first_seen IS NULL"
            )
        except Exception:
            pass

        # Backfill first_seen for rows where it's NULL (shouldn't happen with DEFAULT, but safety)
        try:
            self.conn.execute(
                """
                UPDATE wallets_registry
                SET first_seen = created_at
                WHERE first_seen IS NULL
                """
            )
        except Exception:
            pass

        # Backfill existing rows: unknown age wallets get 'unknown' status
        try:
            self.conn.execute(
                """
                UPDATE wallets_registry
                SET age_status = 'unknown'
                WHERE created_at = '1970-01-01 00:00:00'
                  AND age_status = 'confirmed'
                """
            )
        except Exception:
            pass

    @staticmethod
    def normalize_address(address: str) -> str:
        """Normalize EVM address to lowercase checksummed-agnostic form."""
        return address.strip().lower()

    def load_known_wallets(self) -> set[str]:
        """Load all registered wallet addresses into an in-memory cache set."""
        rows = self.conn.execute(
            "SELECT wallet_address FROM wallets_registry"
        ).fetchall()
        return {self.normalize_address(row[0]) for row in rows}

    def get_wallet(self, wallet_address: str) -> Optional[WalletRecord]:
        """Return wallet metadata if registered, else ``None``."""
        normalized = self.normalize_address(wallet_address)
        row = self.conn.execute(
            """
            SELECT wallet_address, is_insider, created_at, first_seen, age_status
            FROM wallets_registry
            WHERE wallet_address = ?
            """,
            [normalized],
        ).fetchone()
        if row is None:
            return None
        return WalletRecord(
            wallet_address=row[0],
            is_insider=bool(row[1]),
            created_at=row[2],
            first_seen=row[3],
            age_status=str(row[4]) if row[4] else AGE_CONFIRMED,
        )

    def upsert_wallet(
        self,
        wallet_address: str,
        is_insider: bool,
        created_at: datetime,
        age_status: str = AGE_CONFIRMED,
        first_seen: datetime | None = None,
    ) -> None:
        """Insert or update a wallet in the registry."""
        normalized = self.normalize_address(wallet_address)
        if first_seen is None:
            first_seen = datetime.now(timezone.utc)
        self.conn.execute(
            """
            INSERT INTO wallets_registry (wallet_address, is_insider, created_at, age_status, first_seen)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT (wallet_address) DO UPDATE SET
                is_insider = excluded.is_insider,
                created_at = excluded.created_at,
                age_status = excluded.age_status
            """,
            [normalized, is_insider, created_at, age_status, first_seen],
        )

    def insert_insider_trade(
        self,
        trade_id: str,
        wallet_address: str,
        market_id: str,
        market_name: Optional[str] = None,
        volume_usd: float = 0.0,
        timestamp: Optional[datetime] = None,
    ) -> None:
        """Persist a flagged insider trade. Skips duplicate ``trade_id``."""
        normalized = self.normalize_address(wallet_address)
        self.conn.execute(
            """
            INSERT INTO insider_trades
                (trade_id, wallet_address, market_id, market_name, volume_usd, timestamp)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT (trade_id) DO UPDATE SET
                market_name = excluded.market_name
            """,
            [trade_id, normalized, market_id, market_name, volume_usd, timestamp],
        )

    def __enter__(self) -> Database:
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
