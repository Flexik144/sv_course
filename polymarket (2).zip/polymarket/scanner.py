"""Polymarket discovery, WebSocket shards, and Data API trade polling."""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Optional, Set

import aiohttp
import websockets
from websockets.exceptions import ConnectionClosed

logger = logging.getLogger(__name__)

DEFAULT_HEADERS = {"User-Agent": "polymarket-scanner/1.0"}
SUBSCRIBE_BATCH_SIZE = 100


@dataclass(frozen=True)
class ParsedTrade:
    """Normalized trade from Data API, WebSocket, or enrichers."""

    trade_id: str
    market_id: str
    maker: str
    taker: str
    price: float
    size: float
    timestamp: datetime
    proxy_wallet: str = ""
    transaction_hash: str = ""
    extra_addresses: tuple[str, ...] = ()
    market_name: str = ""

    @property
    def volume_usd(self) -> float:
        return self.price * self.size

    @property
    def participant_wallets(self) -> list[str]:
        seen: set[str] = set()
        wallets: list[str] = []
        for address in (
            self.maker,
            self.taker,
            self.proxy_wallet,
            *self.extra_addresses,
        ):
            if not address:
                continue
            normalized = address.strip().lower()
            if normalized not in seen:
                seen.add(normalized)
                wallets.append(normalized)
        return wallets

    def with_addresses(self, addresses: list[str]) -> ParsedTrade:
        """Return a copy with additional participant addresses."""
        merged = tuple(sorted(set(self.extra_addresses) | {a.lower() for a in addresses}))
        proxy = self.proxy_wallet or (merged[0] if merged else "")
        maker = self.maker or proxy
        return replace(self, proxy_wallet=proxy, maker=maker, extra_addresses=merged)


class PollFeedback:
    """Shared counter: pipeline increments when a non-duplicate trade is found,
    poller reads it each cycle to tune interval/limit."""

    def __init__(self) -> None:
        self.new_trades: int = 0


def parse_clob_token_ids(raw: Any) -> list[str]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(token_id) for token_id in raw]
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return []
        if isinstance(parsed, list):
            return [str(token_id) for token_id in parsed]
    return []


def parse_timestamp_ms(raw: Any) -> datetime:
    value = int(raw)
    if value > 1_000_000_000_000:
        value //= 1000
    return datetime.fromtimestamp(value, tz=timezone.utc)


def parse_data_api_trade(row: dict[str, Any]) -> Optional[ParsedTrade]:
    """Parse a row from ``GET /trades``."""
    try:
        price = float(row["price"])
        size = float(row["size"])
        proxy = str(row.get("proxyWallet", "")).lower()
        condition_id = str(row.get("conditionId", ""))
        tx_hash = str(row.get("transactionHash", ""))
        title = str(row.get("title", ""))
        ts_raw = row.get("timestamp", 0)
        timestamp = parse_timestamp_ms(ts_raw)
        trade_id = tx_hash or f"{condition_id}:{proxy}:{int(timestamp.timestamp())}"
        return ParsedTrade(
            trade_id=trade_id,
            market_id=condition_id,
            maker=proxy,
            taker="",
            price=price,
            size=size,
            timestamp=timestamp,
            proxy_wallet=proxy,
            transaction_hash=tx_hash,
            market_name=title,
        )
    except (KeyError, TypeError, ValueError):
        return None


def market_volume(market: dict[str, Any]) -> float:
    for key in ("volume24hr", "volume24hrClob", "volumeNum", "volume"):
        raw = market.get(key)
        if raw is None:
            continue
        try:
            return float(raw)
        except (TypeError, ValueError):
            continue
    return 0.0


class TradeEnricher:
    """Match WS trades to Data API rows for wallet + transaction hash."""

    def __init__(self, data_api_url: str) -> None:
        self.data_api_url = data_api_url.rstrip("/")

    async def enrich(
        self,
        session: aiohttp.ClientSession,
        trade: ParsedTrade,
    ) -> ParsedTrade:
        if trade.participant_wallets and trade.transaction_hash:
            return trade

        params = {"market": trade.market_id, "limit": 30}
        try:
            async with session.get(
                f"{self.data_api_url}/trades",
                params=params,
                headers=DEFAULT_HEADERS,
                timeout=aiohttp.ClientTimeout(total=15),
            ) as response:
                response.raise_for_status()
                rows: list[dict[str, Any]] = await response.json()
        except Exception:
            logger.exception("Failed to enrich trade %s via Data API", trade.trade_id)
            return trade

        trade_ts = int(trade.timestamp.timestamp())
        for row in rows:
            row_price = float(row.get("price", 0))
            row_size = float(row.get("size", 0))
            row_ts = int(row.get("timestamp", 0))
            if abs(row_price - trade.price) > 0.0001:
                continue
            if abs(row_size - trade.size) > 0.01:
                continue
            if abs(row_ts - trade_ts) > 120:
                continue

            proxy = str(row.get("proxyWallet", "")).lower()
            tx_hash = str(row.get("transactionHash", ""))
            trade_id = tx_hash or trade.trade_id
            return ParsedTrade(
                trade_id=trade_id,
                market_id=trade.market_id,
                maker=proxy,
                taker="",
                price=trade.price,
                size=trade.size,
                timestamp=trade.timestamp,
                proxy_wallet=proxy,
                transaction_hash=tx_hash,
                market_name=trade.market_name,
            )

        return trade


class MarketDiscovery:
    """Fetch top markets by 24h volume and expose token IDs for WebSocket shards."""

    def __init__(
        self,
        gamma_api_url: str,
        interval_sec: float = 180.0,
        page_limit: int = 100,
        max_markets: int = 2000,
    ) -> None:
        self.gamma_api_url = gamma_api_url.rstrip("/")
        self.interval_sec = interval_sec
        self.page_limit = page_limit
        self.max_markets = max_markets
        self.active_asset_ids: Set[str] = set()

    async def fetch_market_by_condition_id(
        self,
        session: aiohttp.ClientSession,
        condition_id: str,
    ) -> Optional[dict[str, Any]]:
        """Fetch market details by condition ID."""
        try:
            async with session.get(
                f"{self.gamma_api_url}/markets/{condition_id}",
                headers=DEFAULT_HEADERS,
                timeout=aiohttp.ClientTimeout(total=15),
            ) as response:
                if response.status == 404:
                    return None
                response.raise_for_status()
                return await response.json()
        except Exception:
            logger.exception("Failed to fetch market for condition_id=%s", condition_id)
            return None

    async def fetch_top_asset_ids(self, session: aiohttp.ClientSession) -> Set[str]:
        """Return token IDs for the top ``max_markets`` active markets by volume."""
        markets: list[dict[str, Any]] = []
        offset = 0

        while True:
            params = {
                "active": "true",
                "closed": "false",
                "limit": self.page_limit,
                "offset": offset,
            }
            try:
                async with session.get(
                    f"{self.gamma_api_url}/markets",
                    params=params,
                    headers=DEFAULT_HEADERS,
                    timeout=aiohttp.ClientTimeout(total=30),
                ) as response:
                    if response.status == 422:
                        break
                    response.raise_for_status()
                    page: list[dict[str, Any]] = await response.json()
            except aiohttp.ClientResponseError as exc:
                if exc.status == 422:
                    break
                raise

            if not page:
                break
            markets.extend(page)
            if len(page) < self.page_limit:
                break
            offset += self.page_limit

        markets.sort(key=market_volume, reverse=True)
        top = markets[: self.max_markets]

        asset_ids: set[str] = set()
        for market in top:
            if market.get("acceptingOrders") is False:
                continue
            for token_id in parse_clob_token_ids(market.get("clobTokenIds")):
                asset_ids.add(token_id)

        logger.info(
            "Top %d markets -> %d asset IDs (from %d fetched)",
            len(top),
            len(asset_ids),
            len(markets),
        )
        return asset_ids

    async def run(
        self,
        session: aiohttp.ClientSession,
        on_update: Callable[[Set[str]], Awaitable[None]],
    ) -> None:
        while True:
            try:
                asset_ids = await self.fetch_top_asset_ids(session)
                if asset_ids != self.active_asset_ids:
                    self.active_asset_ids = asset_ids
                    await on_update(asset_ids)
            except Exception:
                logger.exception("Market discovery failed")
            await asyncio.sleep(self.interval_sec)


class TradePoller:
    """Poll global Data API trades (low load, full market coverage).

    Dynamically tunes interval_sec and poll_limit based on
    PollFeedback from the pipeline (ratio of new vs repeat trades).
    """

    def __init__(
        self,
        data_api_url: str,
        interval_sec: float = 4.0,
        poll_limit: int = 100,
        max_retries: int = 3,
        min_interval_sec: float = 0.5,
        max_interval_sec: float = 30.0,
        min_poll_limit: int = 100,
        max_poll_limit: int = 50_000,
        feedback: Optional[PollFeedback] = None,
    ) -> None:
        self.data_api_url = data_api_url.rstrip("/")
        self.interval_sec = interval_sec
        self.poll_limit = poll_limit
        self.max_retries = max_retries
        self.min_interval_sec = min_interval_sec
        self.max_interval_sec = max_interval_sec
        self.min_poll_limit = min_poll_limit
        self.max_poll_limit = max_poll_limit
        self.feedback = feedback
        self._running = False
        self._prev_new_count = 0
        self._prev_total = 0

    def _tune(self, new_ratio: float) -> None:
        """Adjust interval_sec and poll_limit based on new-trade ratio."""
        target_ratio = 0.3  # ideal: 30% of fetched trades are new

        if new_ratio > 0.5:
            # Hot market — fetch more, poll faster
            self.poll_limit = min(int(self.poll_limit * 1.5), self.max_poll_limit)
            self.interval_sec = max(self.interval_sec * 0.8, self.min_interval_sec)
        elif new_ratio < 0.1:
            # Quiet — back off
            self.interval_sec = min(self.interval_sec * 1.5, self.max_interval_sec)
            self.poll_limit = max(int(self.poll_limit / 1.5), self.min_poll_limit)
        else:
            # Moderate — gentle push toward target
            factor = new_ratio / target_ratio
            self.poll_limit = max(self.min_poll_limit,
                                  min(int(self.poll_limit * factor), self.max_poll_limit))
            self.interval_sec = max(self.min_interval_sec,
                                    min(self.interval_sec / factor, self.max_interval_sec))

        logger.info(
            "Poll tune: ratio=%.2f limit=%d interval=%.1fs",
            new_ratio, self.poll_limit, self.interval_sec,
        )

    async def run(
        self,
        session: aiohttp.ClientSession,
        queue: asyncio.Queue[tuple[ParsedTrade, str]],
        source: str = "poll",
    ) -> None:
        self._running = True
        while self._running:
            retry_count = 0
            last_error = None

            while retry_count <= self.max_retries:
                all_rows: list[dict[str, Any]] = []
                try:
                    all_rows = []
                    offset = 0
                    page_size = 1000  # Data API limit per request

                    while offset < self.poll_limit:
                        try:
                            async with session.get(
                                f"{self.data_api_url}/trades",
                                params={"limit": page_size, "offset": offset},
                                headers=DEFAULT_HEADERS,
                                timeout=aiohttp.ClientTimeout(total=15),
                            ) as response:
                                response.raise_for_status()
                                rows: list[dict[str, Any]] = await response.json()

                            if not rows:
                                break

                            all_rows.extend(rows)
                            logger.info(
                                "Trade poll: page %d received %d rows (total: %d)",
                                offset // page_size + 1,
                                len(rows),
                                len(all_rows),
                            )

                            # If we got less than page_size, we've reached the end
                            if len(rows) < page_size:
                                break

                            offset += page_size
                        except aiohttp.ClientResponseError as e:
                            if e.status == 400:
                                logger.info(
                                    "Trade poll: reached API pagination limit at offset %d",
                                    offset,
                                )
                                break
                            raise
                        except asyncio.TimeoutError:
                            if retry_count < self.max_retries:
                                retry_count += 1
                                backoff = min(2 ** retry_count, 10)  # Exponential backoff, max 10s
                                logger.warning(
                                    "Trade poll: timeout on page %d, retry %d/%d in %ds",
                                    offset // page_size + 1,
                                    retry_count,
                                    self.max_retries,
                                    backoff,
                                )
                                await asyncio.sleep(backoff)
                                last_error = "timeout"
                                break  # Break inner loop to retry from beginning
                            raise

                    # If we broke due to timeout, retry the whole poll
                    if last_error == "timeout":
                        continue

                    logger.info("Trade poll: received %d total rows from Data API", len(all_rows))

                    queued = 0
                    for row in all_rows:
                        trade = parse_data_api_trade(row)
                        if trade is not None:
                            try:
                                queue.put_nowait((trade, source))
                                queued += 1
                            except asyncio.QueueFull:
                                logger.warning("Trade queue full, dropping trade")
                                break

                    logger.info("Trade poll: queued %d/%d trades", queued, len(all_rows))
                    break  # Success, exit retry loop

                except asyncio.TimeoutError:
                    if retry_count < self.max_retries:
                        retry_count += 1
                        backoff = min(2 ** retry_count, 10)
                        logger.warning(
                            "Trade poll: timeout, retry %d/%d in %ds",
                            retry_count,
                            self.max_retries,
                            backoff,
                        )
                        await asyncio.sleep(backoff)
                    else:
                        logger.error("Trade poll: timeout after %d retries", self.max_retries)
                        break
                except Exception:
                    logger.exception("Trade poll failed")
                    break

            # ── Dynamic tuning ──────────────────────────────────────
            if self.feedback is not None and self._prev_total > 0:
                now_new = self.feedback.new_trades
                cycle_new = max(0, now_new - self._prev_new_count)
                self._prev_new_count = now_new
                if len(all_rows) > 0:
                    new_ratio = min(cycle_new / max(len(all_rows), self._prev_total), 1.0)
                    self._tune(new_ratio)
            self._prev_total = len(all_rows)

            await asyncio.sleep(self.interval_sec)

    def stop(self) -> None:
        self._running = False


class TradeWebSocketListener:
    """Single WebSocket shard for a subset of asset IDs."""

    PING_INTERVAL_SEC = 10.0
    RECONNECT_DELAY_SEC = 5.0

    def __init__(
        self,
        ws_url: str,
        shard_id: int,
        min_volume_usd: float = 10_000.0,
        on_trade: Optional[Callable[[ParsedTrade], Awaitable[None]]] = None,
    ) -> None:
        self.ws_url = ws_url
        self.shard_id = shard_id
        self.min_volume_usd = min_volume_usd
        self.on_trade = on_trade
        self._asset_ids: Set[str] = set()
        self._ws: Optional[websockets.WebSocketClientProtocol] = None
        self._running = False

    def _build_subscribe_payload(
        self,
        asset_ids: list[str],
        *,
        operation: Optional[str] = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "assets_ids": asset_ids,
            "type": "market",
            "custom_feature_enabled": True,
        }
        if operation:
            payload["operation"] = operation
        return payload

    async def _send_subscribe_batches(
        self,
        ws: websockets.WebSocketClientProtocol,
        asset_ids: list[str],
        *,
        operation: Optional[str] = None,
    ) -> None:
        for index in range(0, len(asset_ids), SUBSCRIBE_BATCH_SIZE):
            batch = asset_ids[index : index + SUBSCRIBE_BATCH_SIZE]
            await ws.send(json.dumps(self._build_subscribe_payload(batch, operation=operation)))
            await asyncio.sleep(0.05)

    async def set_asset_ids(self, asset_ids: Set[str]) -> None:
        """Update subscriptions on the live connection."""
        if self._ws is None:
            self._asset_ids = set(asset_ids)
            return

        new_ids = asset_ids - self._asset_ids
        stale_ids = self._asset_ids - asset_ids
        if stale_ids:
            await self._send_subscribe_batches(
                self._ws, list(stale_ids), operation="unsubscribe"
            )
        if new_ids:
            await self._send_subscribe_batches(
                self._ws, list(new_ids), operation="subscribe"
            )
        self._asset_ids = set(asset_ids)

    @staticmethod
    def parse_trade_message(payload: dict[str, Any]) -> Optional[ParsedTrade]:
        if payload.get("event_type") != "last_trade_price":
            return None
        try:
            price = float(payload["price"])
            size = float(payload["size"])
            market_id = str(payload.get("market") or payload.get("asset_id", ""))
            asset_id = str(payload.get("asset_id", ""))
            timestamp = parse_timestamp_ms(payload.get("timestamp", 0))
            trade_id = f"ws:{market_id}:{asset_id}:{int(timestamp.timestamp() * 1000)}"
            return ParsedTrade(
                trade_id=trade_id,
                market_id=market_id,
                maker="",
                taker="",
                price=price,
                size=size,
                timestamp=timestamp,
            )
        except (KeyError, TypeError, ValueError):
            return None

    async def _ping_loop(self) -> None:
        while self._running and self._ws is not None:
            try:
                await self._ws.send("PING")
            except ConnectionClosed:
                break
            await asyncio.sleep(self.PING_INTERVAL_SEC)

    async def run(self) -> None:
        self._running = True
        while self._running:
            asset_ids = list(self._asset_ids)
            try:
                async with websockets.connect(
                    self.ws_url,
                    ping_interval=None,
                    ping_timeout=None,
                ) as ws:
                    self._ws = ws
                    if asset_ids:
                        await self._send_subscribe_batches(ws, asset_ids)
                        logger.info(
                            "WS shard %d subscribed to %d asset IDs",
                            self.shard_id,
                            len(asset_ids),
                        )

                    ping_task = asyncio.create_task(self._ping_loop())
                    try:
                        async for raw in ws:
                            if raw == "PONG":
                                continue
                            if isinstance(raw, bytes):
                                raw = raw.decode()
                            try:
                                payload = json.loads(raw)
                            except json.JSONDecodeError:
                                continue
                            items = payload if isinstance(payload, list) else [payload]
                            for item in items:
                                await self._handle_payload(item)
                    finally:
                        ping_task.cancel()
                        self._ws = None
            except ConnectionClosed:
                logger.warning("WS shard %d disconnected; reconnecting", self.shard_id)
            except Exception:
                logger.exception("WS shard %d error; reconnecting", self.shard_id)
            finally:
                self._ws = None
                await asyncio.sleep(self.RECONNECT_DELAY_SEC)

    async def _handle_payload(self, payload: dict[str, Any]) -> None:
        trade = self.parse_trade_message(payload)
        if trade is None or trade.volume_usd < self.min_volume_usd:
            return
        if self.on_trade is not None:
            await self.on_trade(trade)

    def stop(self) -> None:
        self._running = False


def split_asset_ids(asset_ids: Set[str], shard_count: int) -> list[Set[str]]:
    """Split asset IDs evenly across shards."""
    if shard_count < 1:
        shard_count = 1
    sorted_ids = sorted(asset_ids)
    shards: list[Set[str]] = [set() for _ in range(shard_count)]
    for index, asset_id in enumerate(sorted_ids):
        shards[index % shard_count].add(asset_id)
    return shards


class ShardedWebSocketPool:
    """Manage multiple WebSocket connections (Variant B)."""

    def __init__(
        self,
        ws_url: str,
        shard_count: int,
        min_volume_usd: float,
        on_trade: Callable[[ParsedTrade], Awaitable[None]],
    ) -> None:
        self.shard_count = max(1, shard_count)
        self.listeners = [
            TradeWebSocketListener(
                ws_url=ws_url,
                shard_id=index,
                min_volume_usd=min_volume_usd,
                on_trade=on_trade,
            )
            for index in range(self.shard_count)
        ]
        self._running = False

    async def update_subscriptions(self, asset_ids: Set[str]) -> None:
        shards = split_asset_ids(asset_ids, self.shard_count)
        await asyncio.gather(
            *(listener.set_asset_ids(shard) for listener, shard in zip(self.listeners, shards))
        )

    async def run(self) -> None:
        self._running = True
        await asyncio.gather(*(listener.run() for listener in self.listeners))

    def stop(self) -> None:
        self._running = False
        for listener in self.listeners:
            listener.stop()
