"""
Backfill: проставляет first_seen для существующих кошельков в БД.

Логика:
  - Для confirmed-кошельков (есть реальная created_at): first_seen = created_at
  - Для unknown-кошельков (created_at = 1970): first_seen = берём мин timestamp
    из insider_trades по этому кошельку.
  - Если first_seen уже проставлен — не трогаем.

Запуск:
    python docs/backfill_first_seen.py
"""

from __future__ import annotations

import logging
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from database import AGE_CONFIRMED, AGE_UNKNOWN, Database

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger("backfill")


def main() -> None:
    db = Database("polymarket_scanner.duckdb")
    db.connect()

    # 1. Добавляем недостающие колонки как init_schema()
    cols = [row[0] for row in db.conn.execute("PRAGMA table_info(wallets_registry)").fetchall()]
    if "age_status" not in cols:
        logger.info("Добавляю колонку age_status...")
        db.conn.execute(
            "ALTER TABLE wallets_registry ADD COLUMN IF NOT EXISTS age_status VARCHAR DEFAULT 'confirmed'"
        )
        db.conn.execute(
            """UPDATE wallets_registry SET age_status = 'unknown' WHERE created_at = '1970-01-01 00:00:00'"""
        )
    if "first_seen" not in cols:
        logger.info("Добавляю колонку first_seen...")
        db.conn.execute(
            "ALTER TABLE wallets_registry ADD COLUMN IF NOT EXISTS first_seen TIMESTAMP DEFAULT now()"
        )

    total = db.conn.execute("SELECT COUNT(*) FROM wallets_registry").fetchone()[0]
    already = db.conn.execute(
        "SELECT COUNT(*) FROM wallets_registry WHERE first_seen IS NOT NULL"
    ).fetchone()[0]
    logger.info("Всего кошельков: %d, уже с first_seen: %d", total, already)

    # 2. Backfill confirmed-кошельков
    c = db.conn.execute("""
        UPDATE wallets_registry
        SET first_seen = created_at
        WHERE first_seen IS NULL
          AND created_at != '1970-01-01 00:00:00'
    """)
    confirmed_count = db.conn.execute(
        "SELECT COUNT(*) FROM wallets_registry WHERE first_seen = created_at AND created_at != '1970-01-01 00:00:00'"
    ).fetchone()[0]
    logger.info("Confirmed: first_seen = created_at (%d строк)", confirmed_count)

    # 3. Backfill unknown-кошельков (1970): ищем первый трейд
    unknown = db.conn.execute("""
        SELECT wallet_address FROM wallets_registry
        WHERE first_seen IS NULL
          AND created_at = '1970-01-01 00:00:00'
    """).fetchall()

    fixed_unknown = 0
    for (addr,) in unknown:
        trade_ts = db.conn.execute("""
            SELECT MIN(timestamp) FROM insider_trades
            WHERE wallet_address = ?
        """, [addr]).fetchone()[0]

        if trade_ts is not None:
            db.conn.execute(
                "UPDATE wallets_registry SET first_seen = ? WHERE wallet_address = ?",
                [trade_ts, addr],
            )
        else:
            db.conn.execute(
                "UPDATE wallets_registry SET first_seen = ? WHERE wallet_address = ?",
                [datetime.now(timezone.utc), addr],
            )
        fixed_unknown += 1

    logger.info("Unknown: first_seen проставлено (%d строк)", fixed_unknown)

    # 4. Ещё раз проверим
    still_null = db.conn.execute(
        "SELECT COUNT(*) FROM wallets_registry WHERE first_seen IS NULL"
    ).fetchone()[0]

    # 5. Итоговая статистика
    print()
    print("=== ИТОГО ПОСЛЕ BACKFILL ===")
    print(f"  Всего кошельков:        {total}")
    print(f"  С first_seen:           {already + confirmed_count + fixed_unknown}")
    print(f"  Без first_seen:         {still_null}")

    unknown_count = db.conn.execute(
        "SELECT COUNT(*) FROM wallets_registry WHERE age_status = 'unknown'"
    ).fetchone()[0]
    confirmed_count_final = db.conn.execute(
        "SELECT COUNT(*) FROM wallets_registry WHERE age_status = 'confirmed'"
    ).fetchone()[0]
    print(f"  age_status=unknown:     {unknown_count}")
    print(f"  age_status=confirmed:   {confirmed_count_final}")

    # 6. Примеры
    print()
    print("=== UNKNOWN КОШЕЛЬКИ (first 5) ===")
    samples = db.conn.execute("""
        SELECT wallet_address, first_seen, created_at, age_status
        FROM wallets_registry
        WHERE age_status = 'unknown'
        LIMIT 5
    """).fetchall()
    for s in samples:
        print(f"  {s[0][:20]}... | first_seen={s[1]} | created={s[2]} | status={s[3]}")

    db.close()
    print()
    logger.info("Backfill завершён!")


if __name__ == "__main__":
    main()
