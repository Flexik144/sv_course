"""
Разведка НОВОГО Polymarket API /trades.

Тестируем официальный эндпоинт из docs.polymarket.com/api-reference/trade/get-trades
и другие эндпоинты, которые могут дать ретро-доступ.

Запуск:
    python docs/probe_new_api.py
"""

from __future__ import annotations

import asyncio
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import aiohttp

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from dotenv import load_dotenv
import os

load_dotenv()

# Старый Data API
OLD_API = os.getenv("DATA_API_URL", "https://data-api.polymarket.com").rstrip("/")
# Новый API из документации
NEW_API = "https://clob.polymarket.com"
GAMMA_API = os.getenv("GAMMA_API_URL", "https://gamma-api.polymarket.com").rstrip("/")
HEADERS = {"User-Agent": "polymarket-scanner/1.0"}


async def test_endpoint(
    session: aiohttp.ClientSession,
    url: str,
    params: dict,
    label: str,
) -> None:
    """Тестирует эндпоинт и выводит результат."""
    try:
        start = datetime.now(timezone.utc)
        async with session.get(
            url, params=params, headers=HEADERS,
            timeout=aiohttp.ClientTimeout(total=15),
        ) as resp:
            elapsed = (datetime.now(timezone.utc) - start).total_seconds()
            body = await resp.text()
            try:
                data = json.loads(body)
            except json.JSONDecodeError:
                data = body[:200]

            if isinstance(data, list):
                count = len(data)
                print(f"  {resp.status:>3d}  {elapsed:>5.1f}s  {count:>6d} rows | {label}")
                if count > 0:
                    first = data[0]
                    ts_keys = [k for k in first.keys() if 'time' in k.lower() or 'date' in k.lower() or 'created' in k.lower()]
                    if ts_keys:
                        print(f"           timestamps: {[(k, str(first[k])[:25]) for k in ts_keys]}")
                    vol = float(first.get("price", 0)) * float(first.get("size", 0))
                    print(f"           sample: price={first.get('price')} size={first.get('size')} vol=${vol:.0f}")
            elif isinstance(data, dict):
                print(f"  {resp.status:>3d}  {elapsed:>5.1f}s  {str(list(data.keys()))[:80]} | {label}")
            else:
                print(f"  {resp.status:>3d}  {elapsed:>5.1f}s  {str(data)[:80]} | {label}")
    except asyncio.TimeoutError:
        print(f"  ⏱️  TIMEOUT  {label}")
    except Exception as e:
        print(f"  ❌  {type(e).__name__}: {str(e)[:60]}  {label}")


async def main() -> None:
    print()
    print("=" * 72)
    print("  🔎 ТЕСТ НОВЫХ ЭНДПОИНТОВ POLYMARKET API")
    print("=" * 72)
    print()

    async with aiohttp.ClientSession(headers=HEADERS) as session:
        # ─── 1. Новый CLOB /trades ─────────────────────────
        print("┌─── 1. НОВЫЙ API: GET /trades ────────────────────────┐")
        await test_endpoint(
            session, f"{NEW_API}/trades",
            {"limit": 3},
            "простой запрос (limit=3)",
        )
        await test_endpoint(
            session, f"{NEW_API}/trades",
            {"limit": 3, "start_date": "2026-06-01", "end_date": "2026-06-05"},
            "с фильтром start_date/end_date",
        )
        await test_endpoint(
            session, f"{NEW_API}/trades",
            {"limit": 3, "startTimestamp": 1780000000, "endTimestamp": 1782580000},
            "с startTimestamp/endTimestamp (unix)",
        )
        print("└──────────────────────────────────────────────────────┘")
        print()

        # ─── 2. /prices-history ─────────────────────────────
        print("┌─── 2. НОВЫЙ API: GET /prices-history ───────────────┐")
        await test_endpoint(
            session, f"{NEW_API}/prices-history",
            {"market": "0xb56bc35aa6debdcb1b1eb7470e7b8de5b473c560b2250c1658d4d29d4e3d38c", "limit": 3},
            "с market (из теста выше)",
        )
        print("└──────────────────────────────────────────────────────┘")
        print()

        # ─── 3. Gamma /markets ──────────────────────────────
        print("┌─── 3. GAMMA: все рынки ───────────────────────────┐")
        await test_endpoint(
            session, f"{GAMMA_API}/markets",
            {"limit": 3, "closed": "false", "active": "true"},
            "активные рынки (limit=3)",
        )
        await test_endpoint(
            session, f"{GAMMA_API}/markets",
            {"limit": 3, "closed": "true"},
            "закрытые рынки (limit=3)",
        )
        print("└──────────────────────────────────────────────────────┘")
        print()

        # ─── 4. Базовые тесты новый API ─────────────────────
        print("┌─── 4. НОВЫЙ API: базовые тесты ────────────────────┐")
        # Пробуем разные пути
        for path in ["/trades", "/data/trades", "/v2/trades"]:
            await test_endpoint(
                session, f"{NEW_API}{path}",
                {"limit": 3},
                f"GET {path}",
            )
        print("└──────────────────────────────────────────────────────┘")
        print()

        # ─── 5. Тест: можно ли через user activity получить трейды ──
        print("┌─── 5. АЛЬТЕРНАТИВНЫЕ ИСТОЧНИКИ ─────────────────────┐")
        # Попробуем разные base URL для API
        for base_name, base_url in [
            ("clob", NEW_API),
            ("gamma", GAMMA_API),
            ("data-api", OLD_API),
        ]:
            for path in ["/trades", "/history", "/all-trades"]:
                url = f"{base_url}{path}"
                await test_endpoint(
                    session, url,
                    {"limit": 2},
                    f"[{base_name}] GET {path}",
                )
        print("└──────────────────────────────────────────────────────┘")
        print()

    print("✅ Разведка завершена.")


if __name__ == "__main__":
    asyncio.run(main())
