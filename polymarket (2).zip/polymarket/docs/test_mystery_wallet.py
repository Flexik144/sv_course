"""
Тестовый скрипт для диагностики mystery-кошельков.

Запускает classify_wallet() на указанном адресе с максимально подробным
логгированием каждого провайдера.

Использование:
    python docs/test_mystery_wallet.py 0x7063a4c81ab684d6d7202a1ddf2ddd4f7dd6fb5d

Без аргумента проверяет все кошельки с age_status='unknown' из БД (если есть).
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

import aiohttp
from dotenv import load_dotenv

# Настраиваем корневой логгер — чтобы видеть всё в консоли
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("test_mystery")

# Подавляем INFO-логи от aiohttp.access
logging.getLogger("aiohttp.access").setLevel(logging.WARNING)

# Импортируем модули проекта
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from checker import GammaWalletAgeProvider, WalletChecker, Web3WalletAgeProvider
from database import Database


async def test_wallet(
    session: aiohttp.ClientSession,
    db: Database,
    wallet_address: str,
    max_age_hours: float = 48.0,
) -> None:
    """
    Проверить один кошелёк со всеми деталями.
    """
    gamma_url = os.getenv("GAMMA_API_URL", "https://gamma-api.polymarket.com")
    alchemy_url = os.getenv("ALCHEMY_RPC_URL", "")

    gamma = GammaWalletAgeProvider(gamma_api_url=gamma_url, session=session)
    alchemy = Web3WalletAgeProvider(
        rpc_url=alchemy_url,
        session=session,
        max_age_hours=max_age_hours,
    )

    checker = WalletChecker(
        db=db,
        known_wallets=set(),
        primary_provider=gamma,
        fallback_provider=alchemy,
        max_age_hours=max_age_hours,
    )

    print()
    print("=" * 72)
    print(f"  🔍 ТЕСТ КОШЕЛЬКА: {wallet_address}")
    print("=" * 72)
    print()

    # Шаг 1: Gamma API
    print("┌─── Шаг 1: Gamma API ──────────────────────────────────────────┐")
    try:
        gamma_start = datetime.now(timezone.utc)
        gamma_age = await gamma.get_wallet_created_at(wallet_address)
        gamma_elapsed = (datetime.now(timezone.utc) - gamma_start).total_seconds()
        if gamma_age is not None:
            print(f"│  ✅ УСПЕХ  ({gamma_elapsed:.1f}s)")
            print(f"│  Дата создания: {gamma_age.isoformat()}")
        else:
            print(f"│  ❌ НЕУДАЧА ({gamma_elapsed:.1f}s)")
            print(f"│  Причина: не удалось получить данные")
    except Exception as e:
        print(f"│  💥 ОШИБКА: {e}")
    print("└──────────────────────────────────────────────────────────────┘")
    print()

    # Шаг 2: Alchemy RPC (только если Gamma не дала результат)
    if gamma_age is None:
        print("┌─── Шаг 2: Alchemy RPC (fallback) ─────────────────────────────┐")
        try:
            alchemy_start = datetime.now(timezone.utc)
            alchemy_age = await alchemy.get_wallet_created_at(wallet_address)
            alchemy_elapsed = (datetime.now(timezone.utc) - alchemy_start).total_seconds()
            if alchemy_age is not None:
                print(f"│  ✅ УСПЕХ  ({alchemy_elapsed:.1f}s)")
                print(f"│  Дата создания: {alchemy_age.isoformat()}")
            else:
                print(f"│  ❌ НЕУДАЧА ({alchemy_elapsed:.1f}s)")
                if not alchemy_url:
                    print(f"│  Причина: ALCHEMY_RPC_URL не настроен")
                else:
                    print(f"│  Причина: транзакции не найдены (новый кошелёк?)")
        except Exception as e:
            print(f"│  💥 ОШИБКА: {e}")
        print("└──────────────────────────────────────────────────────────────┘")
        print()
    else:
        alchemy_age = None

    # Шаг 3: Результат классификации
    print("┌─── Шаг 3: ИТОГОВЫЙ ВЕРДИКТ ────────────────────────────────────┐")
    is_insider, created_at, age_status = await checker.classify_wallet(wallet_address)

    hours_old = (datetime.now(timezone.utc) - created_at.replace(tzinfo=timezone.utc)).total_seconds() / 3600 if created_at else 0

    print(f"│  Кошелёк:          {wallet_address}")
    print(f"│  is_insider:       {is_insider}")
    print(f"│  age_status:       {age_status}")
    print(f"│  created_at:       {created_at.isoformat()}")
    print(f"│  Возраст:          {hours_old:.1f} часов")
    print(f"│  Порог:            {max_age_hours} часов")
    if age_status == "unknown":
        print(f"│  ⚠️  Mystery кошелёк! Возраст не определён.")
        print(f"│  Подробности в logs/mystery_wallets.log")
    print("└──────────────────────────────────────────────────────────────┘")
    print()


async def main() -> None:
    load_dotenv()

    wallet_arg = sys.argv[1] if len(sys.argv) > 1 else None

    # Временная БД в памяти (чтобы не трогать реальную)
    db = Database(":memory:")
    db.connect()

    async with aiohttp.ClientSession(
        headers={"User-Agent": "polymarket-scanner/1.0"}
    ) as session:
        if wallet_arg:
            await test_wallet(session, db, wallet_arg)
        else:
            # Проверяем кошельки из БД с age_status='unknown'
            logger.info("Аргумент не указан. Ищу unknown кошельки в БД...")
            # Сначала пробуем реальную БД
            try:
                real_db = Database("polymarket_scanner.duckdb")
                real_db.connect()
                rows = real_db.conn.execute(
                    "SELECT wallet_address FROM wallets_registry WHERE age_status = 'unknown'"
                ).fetchall()
                real_db.close()
                if rows:
                    logger.info("Найдено %d unknown кошельков в БД", len(rows))
                    for (addr,) in rows:
                        await test_wallet(session, db, addr)
                else:
                    logger.info("В БД нет unknown кошельков. Использую тестовые адреса из истории.")
                    # Тестовые адреса из логов/истории
                    test_addresses = [
                        "0x7063a4c81ab684d6d7202a1ddf2ddd4f7dd6fb5d",  # из переписки — mystery
                        "0xd03450276d4aa4069ce11bac4cfb1683a724eece",  # insider из errors.txt
                        "0x966465d896a84cf3b6bc1695ca1f26c3239b3868",  # активный из check_db.py
                    ]
                    for addr in test_addresses:
                        await test_wallet(session, db, addr)
                        print()
            except Exception as e:
                logger.warning("Не удалось открыть реальную БД: %s", e)
                logger.info("Тестирую адреса из истории:")
                test_addresses = [
                    "0x7063a4c81ab684d6d7202a1ddf2ddd4f7dd6fb5d",
                    "0xd03450276d4aa4069ce11bac4cfb1683a724eece",
                    "0x966465d896a84cf3b6bc1695ca1f26c3239b3868",
                ]
                for addr in test_addresses:
                    await test_wallet(session, db, addr)
                    print()

    db.close()


if __name__ == "__main__":
    asyncio.run(main())
