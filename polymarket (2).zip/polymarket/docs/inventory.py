"""
Инвентаризация: показывает текущее состояние БД, структуру данных,
топ-рынки по объёму, статистику кошельков и сделок.

Запуск:
    python docs/inventory.py
"""

from __future__ import annotations

import sys
from datetime import datetime, timezone
from pathlib import Path

import duckdb

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from database import AGE_CONFIRMED, AGE_UNKNOWN, Database

# ═══════════════════════════════════════════════════════════
#  1. СТАТИСТИКА БД
# ═══════════════════════════════════════════════════════════

db = Database("polymarket_scanner.duckdb")
db.connect()
conn = db.conn

print("=" * 72)
print("  📊 ИНВЕНТАРИЗАЦИЯ ПРОЕКТА Polymarket Insider Scanner")
print("=" * 72)
print()

# ─── СТРУКТУРА ТАБЛИЦ ────────────────────────────────────
print("┌─── СТРУКТУРА ТАБЛИЦ БД ───────────────────────────────┐")
tables = conn.execute("SHOW TABLES").fetchall()
for (t,) in tables:
    print(f"│  📋 {t}")
    cols = conn.execute(f"PRAGMA table_info({t})").fetchall()
    for col in cols:
        nullable = "NULL" if col[3] else "NOT NULL"
        default = f" DEFAULT {col[4]}" if col[4] else ""
        print(f"│     ├ {col[0]:2d}. {col[1]:25s} {col[2]:15s} {nullable}{default}")
    print(f"│")
print("└──────────────────────────────────────────────────────┘")
print()

# ─── ОБЩАЯ СТАТИСТИКА ──────────────────────────────────────
print("┌─── ОБЩАЯ СТАТИСТИКА ───────────────────────────────────┐")

total_wallets = conn.execute("SELECT COUNT(*) FROM wallets_registry").fetchone()[0]
confirmed_w = conn.execute("SELECT COUNT(*) FROM wallets_registry WHERE age_status = 'confirmed'").fetchone()[0]
unknown_w = conn.execute("SELECT COUNT(*) FROM wallets_registry WHERE age_status = 'unknown'").fetchone()[0]
insiders = conn.execute("SELECT COUNT(*) FROM wallets_registry WHERE is_insider = true").fetchone()[0]
non_insiders = conn.execute("SELECT COUNT(*) FROM wallets_registry WHERE is_insider = false").fetchone()[0]

total_trades = conn.execute("SELECT COUNT(*) FROM insider_trades").fetchone()[0]
total_volume = conn.execute("SELECT COALESCE(SUM(volume_usd), 0) FROM insider_trades").fetchone()[0]
avg_volume = conn.execute("SELECT COALESCE(AVG(volume_usd), 0) FROM insider_trades").fetchone()[0]
max_volume = conn.execute("SELECT COALESCE(MAX(volume_usd), 0) FROM insider_trades").fetchone()[0]
unique_markets = conn.execute("SELECT COUNT(DISTINCT market_id) FROM insider_trades").fetchone()[0]

print(f"│  💳 Кошельки:")
print(f"│     Всего:           {total_wallets:>8}")
print(f"│     age=confirmed:   {confirmed_w:>8}")
print(f"│     age=unknown:     {unknown_w:>8}")
print(f"│     is_insider=true: {insiders:>8}")
print(f"│     is_insider=false:{non_insiders:>8}")
print(f"│")
print(f"│  💱 Insider-трейды:")
print(f"│     Всего сделок:    {total_trades:>8}")
print(f"│     Уникальных рынков: {unique_markets:>5}")
print(f"│     Общий объём:    ${total_volume:>10,.2f}")
print(f"│     Средний чек:    ${avg_volume:>10,.2f}")
print(f"│     Макс. сделка:   ${max_volume:>10,.2f}")

# Временной диапазон
ts_min = conn.execute("SELECT MIN(timestamp) FROM insider_trades").fetchone()[0]
ts_max = conn.execute("SELECT MAX(timestamp) FROM insider_trades").fetchone()[0]
print(f"│     Период:          {str(ts_min)[:19]} → {str(ts_max)[:19]}")
print("└──────────────────────────────────────────────────────┘")
print()

# ─── ТОП РЫНКОВ ПО INSIDER-ОБЪЁМУ ─────────────────────────
print("┌─── ТОП-10 РЫНКОВ ПО INSIDER-ОБЪЁМУ ───────────────────┐")
top_markets = conn.execute("""
    SELECT market_name, market_id, COUNT(*) as trades,
           SUM(volume_usd) as total_vol,
           COUNT(DISTINCT wallet_address) as wallets,
           MIN(timestamp) as first_seen,
           MAX(timestamp) as last_seen
    FROM insider_trades
    GROUP BY market_name, market_id
    ORDER BY total_vol DESC
    LIMIT 10
""").fetchall()

print(f"│  {'#':>2s} {'Рынок':45s} {'Сделки':>6s} {'Объём':>12s} {'Кошельки':>8s}")
print(f"│  {'─'*2} {'─'*45} {'─'*6} {'─'*12} {'─'*8}")
for i, m in enumerate(top_markets, 1):
    name = (m[0] or "(нет названия)")[:45]
    print(f"│  {i:2d} {name:45s} {m[2]:6d} ${m[3]:>9,.0f} {m[4]:8d}")
print("└──────────────────────────────────────────────────────┘")
print()

# ─── ТОП КОШЕЛЬКОВ ПО INSIDER-ТРЕЙДАМ ─────────────────────
print("┌─── ТОП-10 КОШЕЛЬКОВ ПО INSIDER-ТРЕЙДАМ ───────────────┐")
top_wallets = conn.execute("""
    SELECT i.wallet_address, w.is_insider, w.age_status,
           COUNT(*) as trades,
           SUM(volume_usd) as total_vol,
           MIN(timestamp) as first_trade,
           MAX(timestamp) as last_trade,
           w.created_at,
           w.first_seen
    FROM insider_trades i
    JOIN wallets_registry w ON i.wallet_address = w.wallet_address
    GROUP BY i.wallet_address, w.is_insider, w.age_status, w.created_at, w.first_seen
    ORDER BY SUM(volume_usd) DESC
    LIMIT 10
""").fetchall()

print(f"│  {'#':>2s} {'Кошелёк':20s} {'I':>3s} {'Статус':10s} {'Сделки':>6s} {'Объём':>12s} {'Создан':12s} {'Обнаружен':12s}")
print(f"│  {'─'*2} {'─'*20} {'─'*3} {'─'*10} {'─'*6} {'─'*12} {'─'*12} {'─'*12}")
for i, w in enumerate(top_wallets, 1):
    addr = w[0][:18] + ".."
    insider_flag = "✅" if w[1] else "❌"
    status = w[2] or "?"
    created = str(w[7])[:10] if w[7] else "?"
    first_seen = str(w[8])[:10] if w[8] else "?"
    print(f"│  {i:2d} {addr:20s} {insider_flag:>3s} {status:10s} {w[3]:6d} ${w[4]:>9,.0f} {created:12s} {first_seen:12s}")
print("└──────────────────────────────────────────────────────┘")
print()

# ─── АКТИВНОСТЬ ПО ДНЯМ ───────────────────────────────────
print("┌─── АКТИВНОСТЬ INSIDER-ТРЕЙДОВ ПО ДНЯМ ────────────────┐")
daily = conn.execute("""
    SELECT DATE(timestamp) as day,
           COUNT(*) as trades,
           SUM(volume_usd) as volume,
           COUNT(DISTINCT wallet_address) as wallets,
           COUNT(DISTINCT market_id) as markets
    FROM insider_trades
    GROUP BY DATE(timestamp)
    ORDER BY day DESC
    LIMIT 14
""").fetchall()

print(f"│  {'Дата':12s} {'Сделки':>6s} {'Объём':>12s} {'Кошельки':>8s} {'Рынки':>5s}")
print(f"│  {'─'*12} {'─'*6} {'─'*12} {'─'*8} {'─'*5}")
for d in daily:
    print(f"│  {str(d[0]):12s} {d[1]:6d} ${d[2]:>9,.0f} {d[3]:8d} {d[4]:5d}")
print("└──────────────────────────────────────────────────────┘")
print()

# ─── ВОЗРАСТНОЕ РАСПРЕДЕЛЕНИЕ ─────────────────────────────
print("┌─── ВОЗРАСТ КОШЕЛЬКОВ (только confirmed) ───────────────┐")
age_stats = conn.execute("""
    SELECT
        CASE
            WHEN created_at >= now() - INTERVAL '1 day' THEN '< 1 день'
            WHEN created_at >= now() - INTERVAL '7 days' THEN '1-7 дней'
            WHEN created_at >= now() - INTERVAL '30 days' THEN '7-30 дней'
            WHEN created_at >= now() - INTERVAL '90 days' THEN '30-90 дней'
            WHEN created_at >= now() - INTERVAL '365 days' THEN '90-365 дней'
            ELSE '> 1 год'
        END as age_range,
        COUNT(*) as count,
        SUM(CASE WHEN is_insider THEN 1 ELSE 0 END) as insiders
    FROM wallets_registry
    WHERE age_status = 'confirmed'
    GROUP BY 1
    ORDER BY MIN(created_at) DESC
""").fetchall()

for a in age_stats:
    print(f"│  {a[0]:15s}  {a[1]:6d} wallets  ({a[2]:4d} insiders)")
print("└──────────────────────────────────────────────────────┘")
print()

# ─── УНИКАЛЬНЫЕ РЫНКИ В INSIDER_TRADES ────────────────────
print("┌─── ВСЕ УНИКАЛЬНЫЕ РЫНКИ В insider_trades ─────────────┐")
all_markets = conn.execute("""
    SELECT DISTINCT market_name, market_id
    FROM insider_trades
    ORDER BY market_name NULLS LAST
""").fetchall()

if all_markets:
    for m in all_markets:
        name = m[0] or "(без названия)"
        mid = m[1][:20] + "..." if m[1] else "?"
        print(f"│  • {name:50s}  ({mid})")
else:
    print(f"│  (нет данных)")
print(f"│")
print(f"│  Всего уникальных рынков: {len(all_markets)}")
print("└──────────────────────────────────────────────────────┘")
print()

# ─── КОНФИГУРАЦИЯ ИЗ .env (без секретов) ─────────────────
print("┌─── ТЕКУЩАЯ КОНФИГУРАЦИЯ (из .env) ────────────────────┐")
from dotenv import load_dotenv
import os
load_dotenv()

config_items = [
    ("MIN_TRADE_VOLUME_USD", "Порог объёма сделки"),
    ("WALLET_MAX_AGE_HOURS", "Макс возраст инсайдера (ч)"),
    ("TRADE_POLL_INTERVAL_SEC", "Интервал опроса Data API (с)"),
    ("TRADE_POLL_LIMIT", "Лимит сделок за poll"),
    ("ENABLE_WS", "WebSocket шарды"),
    ("WS_SHARD_COUNT", "Количество WS-шардов"),
    ("MAX_WS_MARKETS", "Макс рынков для WS"),
    ("WALLET_CHECK_CONCURRENCY", "Параллельность проверки"),
]

for key, desc in config_items:
    val = os.getenv(key, "❌ не задан")
    print(f"│  {key:30s} = {val:10s}   ({desc})")

# Alchemy URL — скрываем ключ
alchemy = os.getenv("ALCHEMY_RPC_URL", "")
if alchemy:
    shown = alchemy[:25] + "..." + alchemy[-8:] if len(alchemy) > 35 else alchemy
else:
    shown = "❌ не задан"
print(f"│  {'ALCHEMY_RPC_URL':30s} = {shown:30s}   (Polygon RPC)")
print("└──────────────────────────────────────────────────────┘")
print()

db.close()
print("✅ Инвентаризация завершена.")
