"""
Метрики производительности Polymarket Insider Scanner.

Показывает:
  - Статус: запущен ли сканер сейчас
  - Счётчики: сделки, кошельки, инсайдеры
  - Ошибки API: таймауты, HTTP-ошибки
  - Распределение: по дням, по часам
  - Последняя активность

Запуск:
    python docs/metrics.py
"""

from __future__ import annotations

import re
import subprocess
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from database import Database


def check_scanner_running() -> tuple[bool, str]:
    """Проверить, запущен ли main.py / сканер сейчас."""
    try:
        if sys.platform == "win32":
            result = subprocess.run(
                ["tasklist", "/NH", "/FO", "CSV"],
                capture_output=True, text=True, timeout=5,
                encoding="utf-8", errors="replace",
            )
            for line in result.stdout.splitlines():
                if "python" in line.lower() and "main.py" in line:
                    return True, "main.py (PID из tasklist)"
            # Также проверяем backup-файлы и процессы Hermes
            result2 = subprocess.run(
                ["tasklist"],
                capture_output=True, text=True, timeout=5,
                encoding="utf-8", errors="replace",
            )
            for line in result2.stdout.splitlines():
                if "python" in line.lower() and any(x in line.lower() for x in ["main.py", "scanner", "hermes"]):
                    return True, line.strip()[:60]
            return False, "не найден"
        else:
            result = subprocess.run(
                ["pgrep", "-f", "main.py"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                pids = result.stdout.strip().split()
                return True, f"main.py (PID: {', '.join(pids)})"
            return False, "не найден"
    except Exception:
        return False, "не удалось проверить"


def parse_errors(errors_path: Path) -> dict:
    """Парсит errors.txt и собирает статистику ошибок."""
    stats = {
        "total_errors": 0,
        "timeout": 0,
        "http_4xx": Counter(),
        "http_5xx": Counter(),
        "exceptions": Counter(),
        "sessions": 0,
    }

    if not errors_path.exists():
        return stats

    text = errors_path.read_text(encoding="utf-8")
    # Каждая сессия начинается с "N:" на отдельной строке
    sessions = re.split(r'\n(?=\d+:\n)', text)
    stats["sessions"] = len([s for s in sessions if s.strip()])

    for line in text.splitlines():
        if "ERROR" in line:
            stats["total_errors"] += 1
        if "TimeoutError" in line:
            stats["timeout"] += 1
        if "ClientResponseError:" in line:
            m = re.search(r'(\d{3})', line)
            if m:
                code = int(m.group(1))
                if 400 <= code < 500:
                    stats["http_4xx"][code] += 1
                elif 500 <= code < 600:
                    stats["http_5xx"][code] += 1

    # Считаем уникальные traceback-исключения
    for m in re.finditer(r'(\w+Error):', text):
        if m.group(1) != "Timeout":  # Timeout уже посчитали отдельно
            stats["exceptions"][m.group(1)] += 1

    return stats


def main() -> None:
    # ─── 1. Статус сканера ────────────────────────────────────────
    running, run_detail = check_scanner_running()
    
    # ─── 2. Данные из БД ──────────────────────────────────────────
    db = Database("polymarket_scanner.duckdb")
    db.connect()
    conn = db.conn

    total_wallets = conn.execute("SELECT COUNT(*) FROM wallets_registry").fetchone()[0]
    confirmed_w = conn.execute(
        "SELECT COUNT(*) FROM wallets_registry WHERE age_status = 'confirmed'"
    ).fetchone()[0]
    unknown_w = conn.execute(
        "SELECT COUNT(*) FROM wallets_registry WHERE age_status = 'unknown'"
    ).fetchone()[0]
    insiders = conn.execute(
        "SELECT COUNT(*) FROM wallets_registry WHERE is_insider = true"
    ).fetchone()[0]

    total_trades = conn.execute("SELECT COUNT(*) FROM insider_trades").fetchone()[0]
    total_vol = conn.execute(
        "SELECT COALESCE(SUM(volume_usd), 0) FROM insider_trades"
    ).fetchone()[0]

    # Последняя активность
    last_trade = conn.execute(
        "SELECT MAX(timestamp) FROM insider_trades"
    ).fetchone()[0]
    last_wallet = conn.execute(
        "SELECT MAX(first_seen) FROM wallets_registry"
    ).fetchone()[0]

    # Активность за последние N периодов
    now = datetime.now(timezone.utc)

    # За час
    trades_1h = conn.execute(
        """SELECT COUNT(*) FROM insider_trades
           WHERE timestamp > now() - INTERVAL '1 hour'"""
    ).fetchone()[0]
    vol_1h = conn.execute(
        """SELECT COALESCE(SUM(volume_usd), 0) FROM insider_trades
           WHERE timestamp > now() - INTERVAL '1 hour'"""
    ).fetchone()[0]
    wallets_1h = conn.execute(
        """SELECT COUNT(*) FROM wallets_registry
           WHERE first_seen > now() - INTERVAL '1 hour'"""
    ).fetchone()[0]

    # За день
    trades_1d = conn.execute(
        """SELECT COUNT(*) FROM insider_trades
           WHERE timestamp > now() - INTERVAL '1 day'"""
    ).fetchone()[0]
    vol_1d = conn.execute(
        """SELECT COALESCE(SUM(volume_usd), 0) FROM insider_trades
           WHERE timestamp > now() - INTERVAL '1 day'"""
    ).fetchone()[0]
    wallets_1d = conn.execute(
        """SELECT COUNT(*) FROM wallets_registry
           WHERE first_seen > now() - INTERVAL '1 day'"""
    ).fetchone()[0]

    # За всё время — средняя интенсивность
    if last_trade:
        first_trade = conn.execute(
            "SELECT MIN(timestamp) FROM insider_trades"
        ).fetchone()[0]
        days = max(1, round((now - first_trade.replace(tzinfo=timezone.utc)).total_seconds() / 86400))
        trades_per_day = round(total_trades / days, 1)
    else:
        days = 0
        trades_per_day = 0.0

    # Топ-3 рынка по числу сделок
    top_markets = conn.execute(
        """SELECT market_name, COUNT(*) as cnt
           FROM insider_trades
           GROUP BY market_name
           ORDER BY cnt DESC LIMIT 3"""
    ).fetchall()

    # Топ-3 кошелька по объёму
    top_wallets = conn.execute(
        """SELECT wallet_address, SUM(volume_usd) as vol
           FROM insider_trades
           GROUP BY wallet_address
           ORDER BY vol DESC LIMIT 3"""
    ).fetchall()

    # ─── 3. Ошибки из errors.txt ─────────────────────────────────
    errors_path = Path(__file__).resolve().parent.parent / "errors.txt"
    err = parse_errors(errors_path)

    # ─── 4. ВЫВОД ─────────────────────────────────────────────────
    print()
    print("═" * 62)
    print("  ⚡ МЕТРИКИ ПРОИЗВОДИТЕЛЬНОСТИ")
    print("═" * 62)
    print()

    # ─ Статус ─
    print("┌─── СТАТУС СКАНЕРА ───────────────────────────────────┐")
    if running:
        print(f"│  🟢 Запущен:          {run_detail}")
    else:
        print(f"│  🔴 Остановлен:       {run_detail}")
    print(f"│  Последняя активность:")
    if last_trade:
        ago = (now - last_trade.replace(tzinfo=timezone.utc)).total_seconds()
        if ago < 3600:
            print(f"│    последний трейд:  {ago:.0f}с назад ({last_trade})")
        else:
            print(f"│    последний трейд:  {ago/3600:.1f}ч назад ({last_trade})")
    else:
        print(f"│    нет трейдов")
    if last_wallet:
        ago_w = (now - last_wallet.replace(tzinfo=timezone.utc)).total_seconds()
        if ago_w < 3600:
            print(f"│    последний кошелёк: {ago_w:.0f}с назад ({last_wallet})")
        else:
            print(f"│    последний кошелёк: {ago_w/3600:.1f}ч назад ({last_wallet})")
    print("└──────────────────────────────────────────────────────┘")
    print()

    # ─ Счётчики ─
    print("┌─── СЧЁТЧИКИ ──────────────────────────────────────────┐")
    print(f"│  💳 Кошельки:")
    print(f"│     Всего:          {total_wallets:>8}")
    print(f"│     confirmed:      {confirmed_w:>8}")
    print(f"│     unknown:        {unknown_w:>8}")
    print(f"│     insiders:       {insiders:>8}")
    print(f"│")
    print(f"│  💱 Insider-трейды:")
    print(f"│     Всего:          {total_trades:>8}")
    print(f"│     Общий объём:    ${total_vol:>10,.0f}")
    print(f"│     Период:         {days} дней")
    print(f"│     Средн./день:    {trades_per_day} трейдов")
    print(f"│")
    print(f"│  📈 За последний час:")
    print(f"│     трейдов:        {trades_1h:>8}   (${vol_1h:>8,.0f})")
    print(f"│     кошельков:      {wallets_1h:>8}")
    print(f"│")
    print(f"│  📈 За последние 24ч:")
    print(f"│     трейдов:        {trades_1d:>8}   (${vol_1d:>8,.0f})")
    print(f"│     кошельков:      {wallets_1d:>8}")
    print("└──────────────────────────────────────────────────────┘")
    print()

    # ─ Ошибки ─
    print("┌─── ОШИБКИ API (из errors.txt) ───────────────────────┐")
    print(f"│  Всего ошибок:      {err['total_errors']:>8}")
    print(f"│  Сессий запуска:    {err['sessions']:>8}")
    print(f"│  Timeout:           {err['timeout']:>8}")
    if err["http_4xx"]:
        codes = ", ".join(f"{c}={n}" for c, n in sorted(err["http_4xx"].items()))
        print(f"│  HTTP 4xx:          {codes}")
    if err["http_5xx"]:
        codes = ", ".join(f"{c}={n}" for c, n in sorted(err["http_5xx"].items()))
        print(f"│  HTTP 5xx:          {codes}")
    if err["exceptions"]:
        exc_str = ", ".join(f"{e}={n}" for e, n in err["exceptions"].most_common(3))
        print(f"│  Исключения:        {exc_str}")
    if err["total_errors"] == 0:
        print(f"│  ✅ Ошибок нет")
    print("└──────────────────────────────────────────────────────┘")
    print()

    # ─ Топы ─
    print("┌─── ТОП-3 ─────────────────────────────────────────────┐")
    print("│  Рынки по числу сделок:")
    for m in top_markets:
        name = (m[0] or "(без названия)")[:45]
        print(f"│    {m[1]:4d} × {name}")
    print("│")
    print("│  Кошельки по объёму:")
    for w in top_wallets:
        addr = w[0][:20] + "..." if len(w[0]) > 20 else w[0]
        print(f"│    ${w[1]:>9,.0f}  {addr}")
    print("└──────────────────────────────────────────────────────┘")
    print()

    # ─ uptime / idle ─
    if not running and last_trade:
        idle_hours = (now - last_trade.replace(tzinfo=timezone.utc)).total_seconds() / 3600
        if idle_hours > 24:
            print(f"  ⏸️  Сканер не работал {idle_hours/24:.0f} дней. Данные устарели.")
        else:
            print(f"  ⏸️  Сканер не работал {idle_hours:.1f} часов.")
    print()

    db.close()


if __name__ == "__main__":
    main()
