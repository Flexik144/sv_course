"""
Proverka privatnogo klucha Polygon koshelka.

Chto delaet:
1. Proverjaet validnost kljucha (format, dekodirovanie)
2. Izvlekaet publichnyj adres
3. Proverjaet balans MATIC i USDC na Polygon cherez Alchemy RPC
4. Probuje zaregistrirovat kljuch v CLOB API Polymarket

Zapusk:
    python docs/check_poly_key.py
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from dotenv import load_dotenv
import os

load_dotenv()

import aiohttp

# --- Konfiguracija -----------------------------------------------
PRIV_KEY = os.getenv("POLY_PRIVATE_KEY", "").strip()
ALCHEMY_URL = os.getenv("ALCHEMY_RPC_URL", "").strip()
CLOB_API = "https://clob.polymarket.com"
HEADERS = {"User-Agent": "polymarket-scanner/1.0"}

USDC_CONTRACT = "0x3c499c542cef5e3811e1192ce70d8cc03d5c3359"


def check_key_format(key: str) -> dict:
    """Proverjaet format privatnogo kljucha."""
    result = {}
    raw = key.removeprefix("0x")

    if len(raw) != 64:
        result["error"] = f"Nevernaja dlina: {len(raw)} hex-simvolov (ozhidalos 64)"
        return result

    try:
        bytes.fromhex(raw)
    except ValueError:
        result["error"] = "Kljuch ne javljaetsja validnoj hex-strokoj"
        return result

    result["raw_length"] = len(raw)
    result["byte_length"] = 32
    result["has_0x_prefix"] = key.startswith("0x")
    result["hex_valid"] = True
    result["format"] = "secp256k1 private key (32 bytes)"
    return result


def derive_address_from_key(key: str) -> str | None:
    try:
        from eth_account import Account
    except ImportError:
        return None
    try:
        raw = key.removeprefix("0x")
        acct = Account.from_key(bytes.fromhex(raw))
        return acct.address
    except Exception as e:
        return f"Oshibka: {e}"


async def check_balance(session: aiohttp.ClientSession, address: str) -> dict:
    if not ALCHEMY_URL:
        return {"error": "ALCHEMY_RPC_URL ne zadan"}
    result = {}

    payload_native = {
        "jsonrpc": "2.0",
        "method": "eth_getBalance",
        "params": [address, "latest"],
        "id": 1,
    }
    try:
        async with session.post(
            ALCHEMY_URL,
            json=payload_native,
            timeout=aiohttp.ClientTimeout(total=10),
        ) as resp:
            data = await resp.json()
            if "result" in data:
                wei = int(data["result"], 16)
                matic = wei / 10**18
                result["matic_balance"] = matic
                result["matic_wei"] = wei
            else:
                result["matic_error"] = data.get("error", "neizvestno")
    except Exception as e:
        result["matic_error"] = str(e)

    addr_hex = address.lower().removeprefix("0x").zfill(64)
    data_field = "0x70a08231" + addr_hex

    payload_usdc = {
        "jsonrpc": "2.0",
        "method": "eth_call",
        "params": [{
            "to": USDC_CONTRACT,
            "data": data_field,
        }, "latest"],
        "id": 2,
    }
    try:
        async with session.post(
            ALCHEMY_URL,
            json=payload_usdc,
            timeout=aiohttp.ClientTimeout(total=10),
        ) as resp:
            data = await resp.json()
            if "result" in data:
                usdc_raw = int(data["result"], 16)
                usdc = usdc_raw / 10**6
                result["usdc_balance"] = usdc
                result["usdc_raw"] = usdc_raw
            else:
                result["usdc_error"] = data.get("error", "neizvestno")
    except Exception as e:
        result["usdc_error"] = str(e)

    return result


async def check_clob_endpoints(session: aiohttp.ClientSession, address: str) -> dict:
    result = {}
    endpoints = [
        ("GET /auth/address/{addr}", f"{CLOB_API}/auth/address/{address}"),
        ("POST /request-api-key (bez body)", f"{CLOB_API}/request-api-key"),
        ("GET /trades (limit=1)", f"{CLOB_API}/trades?limit=1"),
        ("GET /markets (limit=1)", f"{CLOB_API}/markets?limit=1"),
        ("GET /api-keys/{addr}", f"{CLOB_API}/api-keys/{address}"),
    ]
    for label, url in endpoints:
        try:
            method = "POST" if "POST" in label else "GET"
            async with session.request(method, url, headers=HEADERS,
                                        timeout=aiohttp.ClientTimeout(total=10)) as resp:
                body = await resp.text()
                result[label] = {
                    "status": resp.status,
                    "body_preview": body[:120],
                }
        except Exception as e:
            result[label] = {"error": str(e)}
    return result


async def try_clob_registration(session: aiohttp.ClientSession, key: str) -> dict:
    result = {}
    raw_key = key.removeprefix("0x")
    try:
        from eth_account import Account
        from eth_account.messages import encode_typed_data
    except ImportError:
        result["error"] = "eth_account ne ustanovlen"
        return result

    try:
        acct = Account.from_key(bytes.fromhex(raw_key))
        address = acct.address
        result["address"] = address

        # Proverjaem, est li uze CLOB credentials
        auth_url = f"{CLOB_API}/auth/address/{address}"
        async with session.get(auth_url, headers=HEADERS) as resp:
            if resp.status == 200:
                data = await resp.json()
                result["already_registered"] = True
                result["auth_info"] = data
                return result
            else:
                result["already_registered"] = False

        # Sozdajom EIP-712 podpis
        domain = {
            "name": "ClobAuthDomain",
            "version": "1",
            "chainId": 137,
        }

        types = {
            "Registration": [
                {"name": "message", "type": "string"},
            ],
        }

        message = {
            "message": f"Register as API key for {address}"
        }

        signed = Account.sign_typed_data(
            acct.key,
            domain_data=domain,
            types_data=types,
            message_types=types,
            primary_type="Registration",
            message_data=message,
        )

        result["signature"] = signed.signature.hex()
        result["registration_attempted"] = True
        result["note"] = "Podpis sozdana, no format mozhet otlichatsja. Nuzhno izuchit docs.polymarket.com"

    except Exception as e:
        result["error"] = f"{type(e).__name__}: {e}"

    return result


async def main():
    print()
    print("=" * 72)
    print("  [KEY] PROVERKA PRIVATNOGO KLUCHA POLYGON KOSHELKA")
    print("=" * 72)
    print()

    # --- 1. Format kljucha ------------------------------------
    print("+--- 1. PROVERKA FORMATA KLUCHA -------------------------+")
    if not PRIV_KEY:
        print("|  ERR  POLY_PRIVATE_KEY ne najden v .env!")
        print("+------------------------------------------------------+")
        return

    masked = PRIV_KEY[:6] + "..." + PRIV_KEY[-4:]
    print(f"|  Kljuch: {masked}")

    fmt = check_key_format(PRIV_KEY)
    if "error" in fmt:
        print(f"|  ERR  {fmt['error']}")
        print("+------------------------------------------------------+")
        return

    print(f"|  OK   Dlina: {fmt['raw_length']} hex-simvolov ({fmt['byte_length']} bajt)")
    print(f"|  OK   Format: {fmt['format']}")
    print(f"|  OK   0x-prefiks: {'est' if fmt['has_0x_prefix'] else 'net'}")
    print("+------------------------------------------------------+")
    print()

    # --- 2. Publichnyj adres ----------------------------------
    print("+--- 2. IZVLEChENIE PUBLIChNOGO ADRESA ------------------+")
    address = derive_address_from_key(PRIV_KEY)
    if not address:
        print("|  WARN eth_account ne ustanovlen. Ustanavlivaju web3...")
        print("+------------------------------------------------------+")
        import subprocess
        subprocess.run([sys.executable, "-m", "pip", "install", "web3>=6.0.0"])
        address = derive_address_from_key(PRIV_KEY)

    if address and not address.startswith("Oshibka"):
        print(f"|  OK   Adres koshelka: {address}")
    else:
        print(f"|  ERR  {address}")
        print("+------------------------------------------------------+")
        return
    print("+------------------------------------------------------+")
    print()

    # --- 3. Balans --------------------------------------------
    print("+--- 3. BALANS NA POLYGON -------------------------------+")
    async with aiohttp.ClientSession(headers=HEADERS) as session:
        balance = await check_balance(session, address)

        if "matic_balance" in balance:
            print(f"|  MATIC: {balance['matic_balance']:.6f}")
        elif "matic_error" in balance:
            print(f"|  WARN MATIC: oshibka - {balance['matic_error']}")
        else:
            print(f"|  WARN MATIC: net dannyh")

        if "usdc_balance" in balance:
            print(f"|  USDC:  ${balance['usdc_balance']:.2f}")
        elif "usdc_error" in balance:
            print(f"|  WARN USDC: oshibka - {balance['usdc_error']}")
        else:
            print(f"|  WARN USDC: net dannyh")

        print("+------------------------------------------------------+")
        print()

        # --- 4. CLOB API - razvedka ---------------------------
        print("+--- 4. CLOB API - DOSTUPNYE ENDPOINTY ---------------+")
        clob = await check_clob_endpoints(session, address)
        for label, data in clob.items():
            if "error" in data:
                print(f"|  ERR  {label}: {data['error']}")
            else:
                status = data["status"]
                icon = "OK" if status == 200 else "--" if status in (401, 403) else "ERR"
                print(f"|  {icon}  {label}: HTTP {status}")
                if data["body_preview"]:
                    preview = data["body_preview"].replace("\n", " ")
                    print(f"|       otvet: {preview}")
        print("+------------------------------------------------------+")
        print()

        # --- 5. CLOB API - registracija -----------------------
        print("+--- 5. CLOB API - REGISTRACIJA KLUCHA ---------------+")
        reg = await try_clob_registration(session, PRIV_KEY)
        if "error" in reg:
            print(f"|  ERR  {reg['error']}")
        elif reg.get("already_registered"):
            print(f"|  OK   Kljuch UZHE zaregistrirovan v CLOB API!")
            print(f"|  Info: {reg.get('auth_info')}")
        else:
            print(f"|  Adres: {reg.get('address')}")
            print(f"|  Podpis sozdana: {str(reg.get('signature', 'N/A'))[:20]}...")
            print(f"|  Primechanie: {reg.get('note')}")
            print(f"|")
            print(f"|  Nuzhno izuchit tochnyj format registracii v CLOB API.")
            print(f"|  Docs: https://docs.polymarket.com/api/rest/api")
        print("+------------------------------------------------------+")

    print()
    print("=" * 72)
    print("  PROVERKA ZAVERShENA")
    print("=" * 72)
    print()


if __name__ == "__main__":
    asyncio.run(main())
