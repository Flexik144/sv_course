"""Разведочный скрипт: проверяет, какие параметры фильтрации
поддерживает Polymarket Data API /trades.

Запуск:
    python docs/probe_api.py
"""

from __future__ import annotations

import asyncio
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import aiohttp

# Подключаем .env
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from dotenv import load_dotenv
import os

load_dotenv()

DATA_API_URL = os.getenv("DATA_API_URL", "https://data-api.polymarket.com").rstrip("/")
HEADERS = {"User-Agent": "polymarket-scanner/1.0"}


async def try_params(session: aiohttp.ClientSession, params: dict, label: str) -> None:
    """Пробует запрос с параметрами и выводит результат."""
    try:
        start = datetime.now(timezone.utc)
        async with session.get(
            f"{DATA_API_URL}/trades",
            params=params,
            headers=HEADERS,
            timeout=aiohttp.ClientTimeout(total=15),
        ) as resp:
            elapsed = (datetime.now(timezone.utc) - start).total_seconds()
            body = await resp.text()
            data = json.loads(body) if body.strip() else []

            count = len(data)
            status = resp.status
            print(f"  {status:>3d}  {elapsed:>5.1f}s  {count:>6d} rows  | {label}")

            if count > 0:
                # Показываем временной диапазон результата
                first_ts = data[0].get("timestamp", "?")
                last_ts = data[-1].get("timestamp", "?")
                print(f"                  📅 {first_ts} ... {last_ts}")

            return data
    except Exception as e:
        elapsed = (datetime.now(timezone.utc) - start).total_seconds()
        print(f"  ❌   {elapsed:>5.1f}s  {type(e).__name__}: {e}".format(elapsed=elapsed, e=e))
        return []


async def main() -> None:
    print()
    print("=" * 72)
    print("  🔎 РАЗВЕДКА API: Polymarket Data API /trades")
    print("=" * 72)
    print(f"  URL: {DATA_API_URL}/trades")
    print()

    async with aiohttp.ClientSession(headers=HEADERS) as session:
        # ─── 1. Базовый запрос (без параметров) ───────────────
        print("┌─── 1. БАЗОВЫЙ ЗАПРОС ────────────────────────────────┐")
        print("│  Проверяем, что эндпоинт жив и что возвращает")
        await try_params(session, {"limit": 5}, "limit=5 (базовый)")
        print("└──────────────────────────────────────────────────────┘")
        print()

        # ─── 2. Параметры пагинации ────────────────────────────
        print("┌─── 2. ПАГИНАЦИЯ ──────────────────────────────────────┐")
        print("│  Проверяем offset — насколько глубоко можно уйти")
        await try_params(session, {"limit": 5, "offset": 0}, "offset=0")
        await try_params(session, {"limit": 5, "offset": 1000}, "offset=1000")
        await try_params(session, {"limit": 5, "offset": 10000}, "offset=10000")
        await try_params(session, {"limit": 5, "offset": 100000}, "offset=100000")
        await try_params(session, {"limit": 5, "offset": 1000000}, "offset=1000000")
        print("└──────────────────────────────────────────────────────┘")
        print()

        # ─── 3. Параметр market (фильтрация по рынку) ──────────
        print("┌─── 3. ФИЛЬТР ПО РЫНКУ ───────────────────────────────┐")
        print("│  Проверяем market= — фильтрация по conditionId")
        # Берём market_id из первого базового запроса
        base = await try_params(session, {"limit": 1}, "limit=1 (для образца)")
        if base and len(base) > 0:
            sample_market = base[0].get("conditionId", "")
            if sample_market:
                await try_params(
                    session, {"limit": 5, "market": sample_market},
                    f"market={sample_market[:20]}...",
                )
        print("└──────────────────────────────────────────────────────┘")
        print()

        # ─── 4. Параметры времени ──────────────────────────────
        print("┌─── 4. ФИЛЬТРЫ ПО ВРЕМЕНИ ────────────────────────────┐")
        print("│  Пробуем разные форматы: startDate, endDate,")
        print("│  startTimestamp, endTimestamp, startTime, endTime")
        print()

        # Timestamp (Unix seconds) — 1 июня 2026
        ts_start = int(datetime(2026, 6, 1, tzinfo=timezone.utc).timestamp())
        ts_end = int(datetime(2026, 6, 5, tzinfo=timezone.utc).timestamp())

        await try_params(
            session, {"limit": 5, "startTimestamp": ts_start, "endTimestamp": ts_end},
            "startTimestamp/endTimestamp (unix sec)",
        )
        await try_params(
            session, {"limit": 5, "startDate": ts_start, "endDate": ts_end},
            "startDate/endDate (unix sec)",
        )
        await try_params(
            session, {"limit": 5, "startTime": "2026-06-01T00:00:00Z", "endTime": "2026-06-05T00:00:00Z"},
            "startTime/endTime (ISO string)",
        )
        await try_params(
            session, {"limit": 5, "startDate": "2026-06-01", "endDate": "2026-06-05"},
            "startDate/endDate (ISO date)",
        )
        await try_params(
            session, {"limit": 5, "startDate": "2026-06-01T00:00:00Z", "endDate": "2026-06-05T00:00:00Z"},
            "startDate/endDate (ISO datetime)",
        )
        # Ещё один популярный формат:
        await try_params(
            session, {"limit": 5, "start": "2026-06-01", "end": "2026-06-05"},
            "start/end (ISO date)",
        )
        print("└──────────────────────────────────────────────────────┘")
        print()

        # ─── 5. Сортировка ─────────────────────────────────────
        print("┌─── 5. СОРТИРОВКА ─────────────────────────────────────┐")
        await try_params(
            session, {"limit": 5, "order": "asc"},
            "order=asc (без временного фильтра)",
        )
        await try_params(
            session, {"limit": 5, "startDate": "2026-06-01", "endDate": "2026-06-05", "order": "asc"},
            "startDate + endDate + order=asc",
        )
        print("└──────────────────────────────────────────────────────┘")
        print()

        # ─── 6. Максимальный лимит ─────────────────────────────
        print("┌─── 6. МАКСИМАЛЬНЫЙ ЛИМИТ ────────────────────────────┐")
        print("│  Проверяем, сколько строк можно получить за 1 запрос")
        await try_params(session, {"limit": 100}, "limit=100")
        await try_params(session, {"limit": 500}, "limit=500")
        await try_params(session, {"limit": 1000}, "limit=1000")
        await try_params(session, {"limit": 5000}, "limit=5000")
        print("└──────────────────────────────────────────────────────┘")
        print()

    print("✅ Разведка завершена.")


if __name__ == "__main__":
    asyncio.run(main())
