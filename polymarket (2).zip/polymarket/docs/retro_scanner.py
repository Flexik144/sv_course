"""
Retro-skanner: tjanet OrderFilled sobytija iz kontrakta CTF Exchange V2
cherez Alchemy eth_getLogs i zapuskaet pipeline (WalletChecker) na vseh uchastnikah.

Ispolzuet:
  - Alchemy RPC (uzhe est v .env)
  - Gamma API (nazvanija rynkov)
  - Suschestvujuschij Database / WalletChecker

Zapusk:
    python docs/retro_scanner.py [--from-block BLOCK] [--to-block BLOCK] [--batch N]
    python docs/retro_scanner.py --from-block 84902353 --to-block 85000000  # V2 deploy ~28 apr 2026
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys
import time
from argparse import ArgumentParser
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import aiohttp

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from dotenv import load_dotenv
import os

load_dotenv()

from database import Database, AGE_CONFIRMED, AGE_UNKNOWN
from checker import (
    WalletChecker,
    GammaWalletAgeProvider,
    Web3WalletAgeProvider,
    _ensure_mystery_handler,
    mystery_logger,
)

# ─── Konfiguracija ───────────────────────────────────────────────
ALCHEMY_URL = os.getenv("ALCHEMY_RPC_URL", "").strip()
GAMMA_API = os.getenv("GAMMA_API_URL", "https://gamma-api.polymarket.com").rstrip("/")
DB_PATH = os.getenv("DATABASE_PATH", "polymarket_scanner.duckdb")

# Kontrakty CTF Exchange V2
CTF_EXCHANGE_V2 = "0xE111180000d2663C0091e4f400237545B87B996B"
NEG_RISK_EXCHANGE_V2 = "0xe2222d279d744050d28e00520010520000310F59"
EXCHANGES = [CTF_EXCHANGE_V2, NEG_RISK_EXCHANGE_V2]

# Topic0: keccak256("OrderFilled(...)")
TOPIC0_ORDER_FILLED = "0xd543adfd945773f1a62f74f0ee55a5e3b9b1a28262980ba90b1a89f2ea84d8ee"

# Blok razvjortvyvanija V2 (28 aprelja 2026)
V2_DEPLOY_BLOCK = 84902353

# Limity
DEFAULT_BATCH_SIZE = 5000  # blokov za odin zapros
RPC_DELAY = 0.3  # sekund mezhdu RPC zaprosami (300 req/min)
MAX_WORKERS = 4  # parallelnyh proverok WalletChecker

# HEADERS
HEADERS = {"User-Agent": "polymarket-scanner/2.0"}

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("retro_scanner")


# ─── Utility ─────────────────────────────────────────────────────
def decode_order_filled(log: dict) -> Optional[dict]:
    """Dekodiruet OrderFilled sobytie iz eth_getLogs."""
    try:
        topics = log["topics"]
        raw_data = log["data"].removeprefix("0x")
        words = [raw_data[i:i+64] for i in range(0, len(raw_data), 64)]

        if len(words) < 5:
            return None

        maker = "0x" + topics[2][-40:].lower()
        taker = "0x" + topics[3][-40:].lower()
        side = int(words[0], 16)
        token_id = int(words[1], 16)
        maker_amount = int(words[2], 16)
        taker_amount = int(words[3], 16)
        fee = int(words[4], 16)

        # Objom v USD (6 desjatichnyh znakov)
        if side == 0:
            # maker KUPIL shares — platit pUSD
            volume_usd = (maker_amount + fee) / 1e6
        else:
            # maker PRODAL shares — poluchaet pUSD
            volume_usd = taker_amount / 1e6

        return {
            "tx_hash": log["transactionHash"].lower(),
            "block_number": int(log["blockNumber"], 16),
            "log_index": int(log["logIndex"], 16),
            "maker": maker,
            "taker": taker,
            "side": side,
            "token_id": str(token_id),
            "maker_amount": str(maker_amount),
            "taker_amount": str(taker_amount),
            "fee": str(fee),
            "volume_usd": volume_usd,
        }
    except (KeyError, IndexError, ValueError) as e:
        logger.warning("Failed to decode log: %s", e)
        return None


async def get_block_timestamp(session: aiohttp.ClientSession, block_num: int) -> Optional[datetime]:
    """Poluchaet timestamp bloka cherez eth_getBlockByNumber."""
    payload = {
        "jsonrpc": "2.0",
        "method": "eth_getBlockByNumber",
        "params": [hex(block_num), False],
        "id": 1,
    }
    try:
        async with session.post(
            ALCHEMY_URL, json=payload,
            timeout=aiohttp.ClientTimeout(total=10),
        ) as resp:
            data = await resp.json()
            if "result" in data and data["result"]:
                ts_hex = data["result"]["timestamp"]
                ts = int(ts_hex, 16)
                return datetime.fromtimestamp(ts, tz=timezone.utc)
    except Exception as e:
        logger.warning("Failed to get block %d timestamp: %s", block_num, e)
    return None


async def fetch_logs_batch(
    session: aiohttp.ClientSession,
    contract: str,
    from_block: int,
    to_block: int,
) -> list[dict]:
    """Tjanet OrderFilled logy za diapazon blokov."""
    payload = {
        "jsonrpc": "2.0",
        "method": "eth_getLogs",
        "params": [{
            "address": contract,
            "fromBlock": hex(from_block),
            "toBlock": hex(to_block),
            "topics": [TOPIC0_ORDER_FILLED],
        }],
        "id": 1,
    }
    try:
        async with session.post(
            ALCHEMY_URL, json=payload,
            timeout=aiohttp.ClientTimeout(total=30),
        ) as resp:
            data = await resp.json()
            if "error" in data:
                logger.warning("RPC error blocks %d-%d: %s", from_block, to_block, data["error"])
                return []
            return data.get("result", [])
    except Exception as e:
        logger.warning("RPC exception blocks %d-%d: %s", from_block, to_block, e)
        return []


async def resolve_market_name(
    session: aiohttp.ClientSession,
    gamma_api: str,
    condition_id: str | None,
    token_id: str | None,
    cache: dict,
) -> str | None:
    """Poluchaet nazvanie rynka cherez Gamma API s keshirovaniem."""
    if condition_id and condition_id in cache:
        return cache[condition_id]

    # Probujem cherez condition_id
    if condition_id:
        url = f"{gamma_api}/markets/{condition_id}"
        try:
            async with session.get(url, headers=HEADERS, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    title = data.get("title") or data.get("question") or None
                    if title:
                        cache[condition_id] = title
                        return title
        except Exception:
            pass

    # Probujem cherez /markets-by-token/
    if token_id:
        url = f"https://clob.polymarket.com/markets-by-token/{token_id}"
        try:
            async with session.get(url, headers=HEADERS, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    cid = data.get("condition_id")
                    if cid:
                        return await resolve_market_name(session, gamma_api, cid, None, cache)
        except Exception:
            pass

    return None


async def main():
    parser = ArgumentParser(description="Retro-skanner OrderFilled sobytij Polymarket V2")
    parser.add_argument("--from-block", type=int, default=V2_DEPLOY_BLOCK, help="Nachalnyj blok")
    parser.add_argument("--to-block", type=int, default=None, help="Konechnyj blok (default: latest)")
    parser.add_argument("--batch", type=int, default=DEFAULT_BATCH_SIZE, help="Razmer batchinga")
    parser.add_argument("--min-volume", type=float, default=10000, help="Minimalnyj objom dlya insider checka")
    args = parser.parse_args()

    if not ALCHEMY_URL:
        logger.error("ALCHEMY_RPC_URL ne najden v .env!")
        return

    print()
    print("=" * 72)
    print("  [RETRO] SKANNER ORDERFILLED SOBYTIJ POLYMARKET V2")
    print("=" * 72)
    print()

    db = Database(DB_PATH)
    db.connect()
    known_wallets = db.load_known_wallets()
    logger.info("Database: %s, known wallets: %d", DB_PATH, len(known_wallets))

    # Schjotchiki
    stats = {
        "batches": 0,
        "total_logs": 0,
        "decoded": 0,
        "trades_saved": 0,
        "new_wallets": 0,
        "insiders_found": 0,
        "rpc_calls": 0,
        "volume_checked": 0.0,
    }

    from_block = args.from_block
    to_block = args.to_block
    batch_size = args.batch
    min_volume = args.min_volume
    market_cache: dict[str, str] = {}

    async with aiohttp.ClientSession(headers=HEADERS) as session:
        # Sozdajom WalletChecker (kak v main.py)
        gamma_provider = GammaWalletAgeProvider(GAMMA_API, session)
        alchemy_provider = Web3WalletAgeProvider(ALCHEMY_URL, session)
        checker = WalletChecker(
            db=db,
            known_wallets=known_wallets,
            primary_provider=gamma_provider,
            fallback_provider=alchemy_provider,
            max_age_hours=48,
        )

        sem = asyncio.Semaphore(MAX_WORKERS)

        async def classify_and_save(wallet: str) -> bool:
            """Proverjaet koshelek i sohranjaet. Vozvrachaet True esli insider."""
            async with sem:
                if wallet in known_wallets:
                    return False
                try:
                    result = await checker.process_new_wallet(wallet)
                    if result:
                        stats["insiders_found"] += 1
                    stats["new_wallets"] += 1
                    return result
                except Exception as e:
                    logger.error("Wallet check error %s: %s", wallet, e)
                    return False

        # Opredeljaem konechnyj blok
        if to_block is None:
            payload = {"jsonrpc": "2.0", "method": "eth_blockNumber", "params": [], "id": 1}
            async with session.post(ALCHEMY_URL, json=payload, timeout=10) as resp:
                data = await resp.json()
                if "result" in data:
                    to_block = int(data["result"], 16)
                else:
                    to_block = from_block + 50000
            logger.info("Current block: %d", to_block)
            stats["rpc_calls"] += 1
            await asyncio.sleep(RPC_DELAY)

        logger.info("Scanning blocks %d to %d (batch=%d, min_volume=$%.0f)",
                     from_block, to_block, batch_size, min_volume)
        print()

        # Caches dlja timestampov (block_num -> datetime)
        ts_cache: dict[int, datetime] = {}
        seen_txs: set[str] = set()
        pending_wallets: set[str] = set()

        current = from_block
        while current <= to_block:
            end = min(current + batch_size - 1, to_block)

            for contract in EXCHANGES:
                logs = await fetch_logs_batch(session, contract, current, end)
                stats["rpc_calls"] += 1
                stats["total_logs"] += len(logs)

                if not logs:
                    continue

                # Gruppiruem po bloku dlja ekonomii RPC vyzovov
                block_logs: dict[int, list[dict]] = {}
                for log in logs:
                    bn = int(log["blockNumber"], 16)
                    block_logs.setdefault(bn, []).append(log)

                for bn, group in block_logs.items():
                    # Timestamp bloka
                    ts = ts_cache.get(bn)
                    if ts is None:
                        ts = await get_block_timestamp(session, bn)
                        stats["rpc_calls"] += 1
                        if ts:
                            ts_cache[bn] = ts
                        await asyncio.sleep(RPC_DELAY)

                    for log in group:
                        trade = decode_order_filled(log)
                        if trade is None:
                            continue
                        stats["decoded"] += 1

                        # Skip esli uzhe videli tx_hash
                        tx_key = f"{trade['tx_hash']}:{trade['log_index']}"
                        if tx_key in seen_txs:
                            continue
                        seen_txs.add(tx_key)

                        volume = trade["volume_usd"]
                        if volume < min_volume:
                            continue

                        stats["volume_checked"] += volume
                        maker = trade["maker"]
                        taker = trade["taker"]

                        # Dobavljaem koshelki v ochered na proverku
                        for wallet in [maker, taker]:
                            if wallet not in known_wallets and wallet not in pending_wallets:
                                pending_wallets.add(wallet)

                        # Sozdaem trade_id
                        trade_id = f"{trade['tx_hash']}:{maker}"
                        market_id = trade["token_id"]

                        # Rezolvim nazvanie rynka (async, s keshem)
                        market_name = await resolve_market_name(
                            session, GAMMA_API, None, market_id, market_cache,
                        )
                        if market_name is None:
                            market_name = f"token:{market_id[:16]}..."

                        # Sohranjaem trejd
                        db.insert_insider_trade(
                            trade_id=trade_id,
                            wallet_address=maker,
                            market_id=market_id,
                            market_name=market_name,
                            volume_usd=volume,
                            timestamp=ts or datetime.now(timezone.utc),
                        )
                        stats["trades_saved"] += 1

            # Progress
            progress = (current - from_block) / (to_block - from_block) * 100
            print(f"  [{progress:5.1f}%] blocks {current}..{end} | "
                  f"logs={stats['total_logs']} decoded={stats['decoded']} "
                  f"trades={stats['trades_saved']} wallets={len(pending_wallets)} "
                  f"rpc={stats['rpc_calls']}", end="\r")

            current = end + 1
            stats["batches"] += 1

            # Delay mezhdu batchami — rate limiting
            await asyncio.sleep(RPC_DELAY)

        # 4. Proverjaem vse novye koshelki
        print()
        print()
        logger.info("Checking %d new wallets...", len(pending_wallets))
        checked = 0
        for wallet in pending_wallets:
            if wallet not in known_wallets:
                await classify_and_save(wallet)
                checked += 1
                if checked % 10 == 0:
                    print(f"  wallets checked: {checked}/{len(pending_wallets)}", end="\r")

        print()
        print()
        logger.info("Wallet check complete: %d checked, %d insiders found", checked, stats["insiders_found"])

    # 5. Itogi
    print()
    print("=" * 72)
    print("  STATISTIKA RETRO-SKANIROVANIJA")
    print("=" * 72)
    print(f"  Bloki:          {from_block} -> {to_block} ({to_block - from_block + 1} blokov)")
    print(f"  Batchingov:     {stats['batches']}")
    print(f"  RPC vyzovov:    {stats['rpc_calls']}")
    print(f"  Vsego logov:    {stats['total_logs']}")
    print(f"  Dekodirovano:   {stats['decoded']}")
    print(f"  Trades save:    {stats['trades_saved']}")
    print(f"  Objem checked:  ${stats['volume_checked']:.2f}")
    print(f"  Novyh koshelkov:{stats['new_wallets']}")
    print(f"  Insiderov:      {stats['insiders_found']}")
    print("=" * 72)
    print()

    db.close()


if __name__ == "__main__":
    asyncio.run(main())
