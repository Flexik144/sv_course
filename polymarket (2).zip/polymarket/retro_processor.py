"""
Phase 2: Process historical trades from filtered_10k.parquet through WalletChecker.
Batch-checks wallets via Gamma API + Alchemy, saves insider trades to DuckDB.

Usage: python retro_processor.py [--max-wallets N] [--concurrency N]
"""
from __future__ import annotations

import argparse
import asyncio
import logging
import os
import sys
import time
from datetime import datetime, timezone
from typing import Optional

from dotenv import load_dotenv
import aiohttp
import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.dataset as ds
import pyarrow.parquet as pq

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from database import Database

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
# Silence noisy loggers
logging.getLogger("checker").setLevel(logging.WARNING)
logging.getLogger("mystery_wallets").setLevel(logging.WARNING)

logger = logging.getLogger("retro")

# ─── helpers ───────────────────────────────────────────────────────────────

def sizeof_fmt(num):
    for unit in ("B", "KB", "MB", "GB"):
        if abs(num) < 1024:
            return f"{num:.1f} {unit}"
        num /= 1024
    return f"{num:.1f} TB"


# ─── batch wallet checker ──────────────────────────────────────────────────

class RetroWalletChecker:
    """Check many wallets in batch with concurrency."""

    def __init__(
        self,
        db: Database,
        gamma_url: str,
        alchemy_url: str,
        max_age_hours: float = 48.0,
        concurrency: int = 20,
        verbose: bool = False,
    ) -> None:
        self.db = db
        self.gamma_url = gamma_url
        self.alchemy_url = alchemy_url
        self.max_age_hours = max_age_hours
        self.concurrency = concurrency
        self.verbose = verbose
        self.gamma_timeout = 8  # seconds — short timeout, if Gamma slow just skip
        self._known_wallets: set[str] = set()
        self._sem: asyncio.Semaphore | None = None

    async def startup(self) -> None:
        self.db.connect()
        self._known_wallets = self.db.load_known_wallets()
        logger.info("Loaded %d known wallets from DB", len(self._known_wallets))
        self._sem = asyncio.Semaphore(self.concurrency)

    async def check_wallet(
        self,
        session: aiohttp.ClientSession,
        wallet: str,
        reference_ts: int,  # Unix timestamp of the wallet's first large trade
    ) -> dict:
        """Check a single wallet. Returns result dict."""
        wallet_lower = wallet.lower()
        result = {
            "wallet": wallet_lower,
            "is_insider": False,
            "created_at": None,
            "age_status": "unknown",
            "reference_ts": reference_ts,
            "age_hours_at_trade": None,
        }

        # Already known?
        if wallet_lower in self._known_wallets:
            record = self.db.get_wallet(wallet_lower)
            if record:
                result["created_at"] = record.created_at
                result["age_status"] = record.age_status
                if record.created_at and record.age_status == "alchemy":
                    age_at_trade = reference_ts - record.created_at.timestamp()
                    result["age_hours_at_trade"] = age_at_trade / 3600
                    result["is_insider"] = age_at_trade < self.max_age_hours * 3600 and age_at_trade >= 0
                elif record.created_at and record.age_status == "gamma":
                    # Gamma = Polymarket registration, use short threshold
                    age_at_trade = reference_ts - record.created_at.timestamp()
                    result["age_hours_at_trade"] = age_at_trade / 3600
                    result["is_insider"] = age_at_trade < 0.5 * 3600 and age_at_trade >= 0  # < 30 min
                elif record.age_status == "confirmed":
                    # Original live scanner record — trust its classification
                    result["is_insider"] = record.is_insider
                elif record.is_insider:
                    result["is_insider"] = True
                return result

        created_at = None
        age_status = "unknown"

        # Gamma only (fast, public API) with short timeout
        try:
            async with session.get(
                f"{self.gamma_url}/public-profile",
                params={"address": wallet_lower},
                headers={"User-Agent": "polymarket-scanner/1.0"},
                timeout=aiohttp.ClientTimeout(total=self.gamma_timeout),
            ) as response:
                if response.status == 200:
                    profile = await response.json()
                    created_raw = profile.get("createdAt")
                    if created_raw:
                        created_at = datetime.fromisoformat(created_raw.replace("Z", "+00:00"))
                        age_status = "gamma"
                elif response.status == 404:
                    pass  # No profile — unknown
        except Exception:
            pass  # Timeout or error — skip, not insider

        result["created_at"] = created_at
        result["age_status"] = age_status

        if created_at:
            age_at_trade = reference_ts - created_at.timestamp()
            result["age_hours_at_trade"] = age_at_trade / 3600
            # Gamma = Polymarket registration, use < 30 min
            result["is_insider"] = age_at_trade < 0.5 * 3600 and age_at_trade >= 0

            if self.verbose:
                logger.info(
                    "Wallet %s: created=%s, age_at_trade=%.1fh, insider=%s",
                    wallet_lower[:10],
                    created_at.isoformat(),
                    age_at_trade / 3600,
                    result["is_insider"],
                )

        # Persist
        normalized = self.db.normalize_address(wallet_lower)
        self.db.upsert_wallet(
            normalized,
            is_insider=result["is_insider"],
            created_at=created_at or datetime(1970, 1, 1, tzinfo=timezone.utc),
            age_status=age_status,
            first_seen=datetime.now(timezone.utc),
        )
        self._known_wallets.add(wallet_lower)

        return result

    async def check_batch(
        self,
        session: aiohttp.ClientSession,
        wallets: list[tuple[str, int]],  # (wallet_address, first_trade_ts)
        batch_size: int = 500,
    ) -> list[dict]:
        """Check wallets in small batches with progress logging."""
        sem = self._sem
        assert sem is not None

        async def _check(wallet: str, ts: int) -> dict:
            async with sem:
                return await self.check_wallet(session, wallet, ts)

        all_results: list[dict] = []
        total = len(wallets)
        t0 = time.time()
        for start in range(0, total, batch_size):
            end = min(start + batch_size, total)
            batch = wallets[start:end]
            tasks = [_check(w, ts) for w, ts in batch]
            batch_results = await asyncio.gather(*tasks)
            all_results.extend(batch_results)

            elapsed = time.time() - t0
            rate = end / elapsed if elapsed > 0 else 0
            insider_cnt = sum(1 for r in batch_results if r["is_insider"])
            logger.info(
                "Batch check: %d/%d wallets done (%.1f%%) in %.0fs (%.0f w/s), "
                "batch insiders=%d, total insiders=%d",
                end, total, 100 * end / total, elapsed, rate,
                insider_cnt, sum(1 for r in all_results if r["is_insider"]),
            )

            # Periodic GC
            if start > 0 and start % 2000 == 0:
                import gc; gc.collect()

        return all_results


# ─── main ──────────────────────────────────────────────────────────────────

async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-wallets", type=int, default=None, help="Limit wallets to check (dev)")
    parser.add_argument("--concurrency", type=int, default=20, help="Max concurrent API calls")
    parser.add_argument("--verbose", action="store_true", help="Log each wallet check")
    args = parser.parse_args()

    load_dotenv()

    PARQUET_PATH = "C:/hermes/polymarket/data/filtered_10k.parquet"
    DB_PATH = "C:/hermes/polymarket/polymarket_scanner.duckdb"
    GAMMA_URL = "https://gamma-api.polymarket.com"
    ALCHEMY_URL = os.getenv("ALCHEMY_RPC_URL", "")

    if not ALCHEMY_URL:
        logger.warning("ALCHEMY_RPC_URL not set — Alchemy fallback disabled")

    t_start = time.time()

    # Step 1: Load filtered parquet
    logger.info("Loading filtered trades from %s ...", PARQUET_PATH)
    dataset = ds.dataset(PARQUET_PATH, format="parquet")
    table = dataset.to_table()
    logger.info("Loaded %s trades (%.2f MB)", f"{table.num_rows:,}", table.nbytes / 1024**2)

    # Step 2: Get first trade timestamp per wallet (using DuckDB for speed)
    import duckdb
    con = duckdb.connect()
    wallet_first = con.execute(f"""
        SELECT
            LOWER(maker) AS wallet,
            CAST(MIN(timestamp) AS BIGINT) AS first_trade_ts
        FROM read_parquet('{PARQUET_PATH}')
        GROUP BY wallet
        UNION
        SELECT
            LOWER(taker) AS wallet,
            CAST(MIN(timestamp) AS BIGINT) AS first_trade_ts
        FROM read_parquet('{PARQUET_PATH}')
        GROUP BY wallet
    """).fetchall()
    con.close()

    # Aggregate — keep min per wallet
    wallet_map: dict[str, int] = {}
    for w, ts in wallet_first:
        w_lower = w.lower()
        if w_lower not in wallet_map or ts < wallet_map[w_lower]:
            wallet_map[w_lower] = ts

    wallets_list = sorted(wallet_map.items())  # (wallet, first_trade_ts)
    if args.max_wallets:
        wallets_list = wallets_list[:args.max_wallets]

    logger.info("Unique wallets to check: %s", f"{len(wallets_list):,}")
    n_old = sum(1 for _, ts in wallets_list if ts < 1700000000)  # before Nov 2023
    n_recent = len(wallets_list) - n_old
    logger.info("  Wallets with first trade before Nov 2023: %s", f"{n_old:,}")
    logger.info("  Wallets with first trade after Nov 2023:  %s", f"{n_recent:,}")

    # Step 3: Initialize DB and checker
    db = Database(DB_PATH)
    checker = RetroWalletChecker(
        db=db,
        gamma_url=GAMMA_URL,
        alchemy_url=ALCHEMY_URL,
        concurrency=args.concurrency,
        verbose=args.verbose,
    )
    await checker.startup()

    # Step 4: Batch check wallets
    logger.info("Starting batch wallet check (concurrency=%d)...", args.concurrency)
    t_check = time.time()

    async with aiohttp.ClientSession(
        headers={"User-Agent": "polymarket-scanner/1.0"}
    ) as session:
        results = await checker.check_batch(session, wallets_list)

    elapsed_check = time.time() - t_check
    insider_wallets = [r for r in results if r["is_insider"]]
    logger.info(
        "Wallet check complete: %d wallets checked in %.1fs (%.1f wallets/s)",
        len(results),
        elapsed_check,
        len(results) / elapsed_check if elapsed_check > 0 else 0,
    )
    logger.info("Insider wallets found: %d", len(insider_wallets))

    # Step 5: Insert insider trades from the filtered parquet
    if insider_wallets:
        logger.info("Inserting insider trades into DB...")
        insider_set = set(r["wallet"] for r in insider_wallets)

        # Read all filtered trades, find ones with insider wallets (case-insensitive)
        trades_table = dataset.to_table()
        maker_lower = pc.utf8_lower(trades_table.column("maker"))
        taker_lower = pc.utf8_lower(trades_table.column("taker"))
        maker_mask = pc.is_in(maker_lower, pa.array(list(insider_set)))
        taker_mask = pc.is_in(taker_lower, pa.array(list(insider_set)))
        combined_mask = pc.or_(maker_mask, taker_mask)
        insider_trades = trades_table.filter(combined_mask)

        logger.info(
            "Insider trades to insert: %d (out of %d filtered trades)",
            insider_trades.num_rows,
            trades_table.num_rows,
        )

        # Insert in batches
        timestamps = insider_trades.column("timestamp").to_pylist()
        markets = insider_trades.column("market_id").to_pylist()
        amounts = insider_trades.column("usd_amount").to_pylist()
        makers = insider_trades.column("maker").to_pylist()
        takers = insider_trades.column("taker").to_pylist()
        tx_hashes = insider_trades.column("transaction_hash").to_pylist()

        inserted = 0
        for i in range(len(timestamps)):
            trade_ts = timestamps[i]
            market = markets[i]
            vol = amounts[i]
            maker = makers[i].lower()
            taker = takers[i].lower()
            tx_hash = tx_hashes[i]

            # Insert per-wallet (maker and taker) — lowercase comparison
            if maker.lower() in insider_set:
                trade_id = f"{tx_hash}:{maker.lower()}"
                db.insert_insider_trade(
                    trade_id=trade_id,
                    wallet_address=maker.lower(),
                    market_id=str(market),
                    volume_usd=vol,
                    timestamp=datetime.fromtimestamp(trade_ts, tz=timezone.utc),
                )
                inserted += 1
            if taker.lower() in insider_set:
                trade_id = f"{tx_hash}:{taker.lower()}"
                db.insert_insider_trade(
                    trade_id=trade_id,
                    wallet_address=taker.lower(),
                    market_id=str(market),
                    volume_usd=vol,
                    timestamp=datetime.fromtimestamp(trade_ts, tz=timezone.utc),
                )
                inserted += 1

        logger.info("Inserted %d insider trades", inserted)

        # Log top insider wallets
        from collections import Counter
        wallet_counts = Counter()
        for r in insider_wallets:
            # Count trades for this wallet
            w = r["wallet"]
            cnt = sum(1 for m, t in zip(makers, takers) if m.lower() == w or t.lower() == w)
            wallet_counts[w] = cnt

        logger.info("Top 20 insider wallets:")
        for w, cnt in wallet_counts.most_common(20):
            age_h = next((r["age_hours_at_trade"] for r in insider_wallets if r["wallet"] == w), None)
            age_str = f"age=~{age_h:.0f}h" if age_h else "age=unknown"
            logger.info("  %s: %d trades %s", w[:10], cnt, age_str)
    else:
        logger.info("No insider wallets found — nothing to insert")

    total_elapsed = time.time() - t_start
    logger.info("Phase 2 complete in %.1fs", total_elapsed)
    db.close()


if __name__ == "__main__":
    asyncio.run(main())
