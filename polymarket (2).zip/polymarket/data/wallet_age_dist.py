"""Check distribution of first-trade timestamps per wallet in filtered data."""
import pyarrow.parquet as pq
import pyarrow.compute as pc
import pyarrow.dataset as ds
import time, datetime

PATH = "C:/hermes/polymarket/data/filtered_10k.parquet"

print("Loading filtered data...", flush=True)
dataset = ds.dataset(PATH, format="parquet")
table = dataset.to_table()

# Get min timestamp per maker and taker
print("Computing first-trade stats per wallet...", flush=True)

# Maker first trades
maker_min = table.select(["maker", "timestamp"]).group_by("maker").aggregate([("timestamp", "min")])
maker_min = maker_min.rename_columns(["wallet", "first_trade_ts"])

# Taker first trades
taker_min = table.select(["taker", "timestamp"]).group_by("taker").aggregate([("timestamp", "min")])
taker_min = taker_min.rename_columns(["wallet", "first_trade_ts"])

# Combine
import pyarrow as pa
combined = pa.concat_tables([maker_min, taker_min])
wallet_first = combined.group_by("wallet").aggregate([("first_trade_ts", "min")])

print(f"Total unique wallets: {wallet_first.num_rows:,}", flush=True)
print(f"Schema: {wallet_first.schema}", flush=True)

# Distribution - convert to python lists
col_name = wallet_first.schema.names[1]
first_ts_list = wallet_first.column(col_name).to_pylist()
min_ts = min(first_ts_list)
max_ts = max(first_ts_list)
print(f"First-trade range: {datetime.datetime.fromtimestamp(min_ts)} to {datetime.datetime.fromtimestamp(max_ts)}", flush=True)

# Buckets
now = max_ts
buckets = {
    "last_24h": (now - 86400, now),         # 0-1 day
    "last_48h": (now - 172800, now - 86400),  # 1-2 days
    "last_week": (now - 604800, now - 172800), # 2-7 days
    "last_month": (now - 2592000, now - 604800), # 7-30 days
    "last_3m": (now - 7776000, now - 2592000),  # 1-3 months
    "last_6m": (now - 15552000, now - 7776000),  # 3-6 months
    "last_year": (now - 31104000, now - 15552000), # 6-12 months
    "older": (0, now - 31104000),  # > 1 year
}

col_name = wallet_first.schema.names[1]
for label, (lo, hi) in buckets.items():
    mask = pc.and_(
        pc.greater_equal(wallet_first.column(col_name), lo),
        pc.less(wallet_first.column(col_name), hi),
    )
    count = pc.sum(mask).as_py()
    print(f"  First trade in {label}: {count:,} wallets ({100*count/wallet_first.num_rows:.1f}%)", flush=True)

# Also check: wallets whose first trade > $10K
print("\nChecking wallets where first trade >= $10K...", flush=True)
# Join: for each wallet, find the minimum timestamp trade
# Then check if that trade was >= $10K
# This is complex in PyArrow, let me use a simpler approach
# Look at the first trade per wallet and its value
print("Done.", flush=True)
