"""Phase 2: Filter quant.parquet for trades >= $10K using PyArrow."""
import pyarrow.parquet as pq
import pyarrow.dataset as ds
import time

PATH = "C:/hermes/polymarket/data/quant.parquet"

print("Opening parquet file...", flush=True)
t0 = time.time()

# Read schema and filter
dataset = ds.dataset(PATH, format="parquet")
schema = dataset.schema
print(f"Schema: {schema}", flush=True)
print(f"Opened in {time.time()-t0:.1f}s", flush=True)

# Get row group info
f = pq.ParquetFile(PATH)
print(f"Metadata: {f.metadata.num_rows:,} rows, {f.metadata.num_row_groups} row groups", flush=True)

# Row group 0 stats for usd_amount
for i in range(min(3, f.metadata.num_row_groups)):
    rg = f.metadata.row_group(i)
    for j in range(rg.num_columns):
        col = rg.column(j)
        if col.path_in_schema == "usd_amount":
            stats = col.statistics
            if stats:
                print(f"  RG {i} usd_amount: min={stats.min}, max={stats.max}, null_count={stats.null_count}")
            break

# Filter with PyArrow dataset
print("\nFiltering for usd_amount >= 10000...", flush=True)
t1 = time.time()
scanner = dataset.scanner(
    columns=["timestamp", "market_id", "usd_amount", "maker", "taker", "transaction_hash", "price", "side"],
    filter=ds.field("usd_amount") >= 10000.0,
)
table = scanner.to_table()
elapsed = time.time() - t1
print(f"Filtered: {table.num_rows:,} rows in {elapsed:.1f}s", flush=True)

# Date range
ts = table.column("timestamp").to_pylist()
if ts:
    min_ts = min(ts)
    max_ts = max(ts)
    import datetime
    print(f"Date range: {datetime.datetime.fromtimestamp(min_ts)} to {datetime.datetime.fromtimestamp(max_ts)}", flush=True)

# Unique wallets
makers = set(table.column("maker").to_pylist())
takers = set(table.column("taker").to_pylist())
all_wallets = makers | takers
print(f"Unique makers: {len(makers):,}", flush=True)
print(f"Unique takers: {len(takers):,}", flush=True)
print(f"Unique wallets (maker|taker): {len(all_wallets):,}", flush=True)

# Save filtered data as a new parquet
OUT = "C:/hermes/polymarket/data/filtered_10k.parquet"
print(f"\nSaving to {OUT}...", flush=True)
pq.write_table(table, OUT)
print(f"Saved! File size: {__import__('os').path.getsize(OUT) / 1024**3:.2f} GB", flush=True)
