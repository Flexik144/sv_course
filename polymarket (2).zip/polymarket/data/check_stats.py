"""Check parquet: filtered counts."""
import duckdb

con = duckdb.connect()
PATH = "C:/hermes/polymarket/data/quant.parquet"

# Total
r = con.execute(f"SELECT count(*) FROM read_parquet('{PATH}')").fetchone()
print(f"Total rows: {r[0]:,}")

# Try with explicit cast
r = con.execute(f"SELECT count(*) FROM read_parquet('{PATH}') WHERE CAST(usd_amount AS DOUBLE) >= 10000").fetchone()
print(f"Trades >= $10K (cast): {r[0]:,}")

# Try date range via LIMIT-based min/max
rows = con.execute(f"SELECT timestamp FROM read_parquet('{PATH}') ORDER BY timestamp LIMIT 1").fetchone()
print(f"First timestamp: {rows[0]} ({__import__('datetime').datetime.fromtimestamp(rows[0])})")
rows = con.execute(f"SELECT timestamp FROM read_parquet('{PATH}') ORDER BY timestamp DESC LIMIT 1").fetchone()
print(f"Last timestamp: {rows[0]} ({__import__('datetime').datetime.fromtimestamp(rows[0])})")
