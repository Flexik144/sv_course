"""Quick verification of restored DB."""
import duckdb

con = duckdb.connect("C:/hermes/polymarket/polymarket_scanner.duckdb")

trades = con.execute("SELECT count(*) FROM insider_trades").fetchone()[0]
wallets = con.execute("SELECT count(*) FROM wallets_registry").fetchone()[0]
insiders = con.execute("SELECT count(*) FROM wallets_registry WHERE is_insider = true").fetchone()[0]
print(f"Trades: {trades}")
print(f"Wallets: {wallets}")
print(f"Insiders: {insiders}")
con.close()
