"""Verify final DB state after Phase 2."""
import duckdb
from datetime import datetime

con = duckdb.connect("C:/hermes/polymarket/polymarket_scanner.duckdb")

trades = con.execute("SELECT count(*) FROM insider_trades").fetchone()[0]
wallets = con.execute("SELECT count(*) FROM wallets_registry").fetchone()[0]
insiders = con.execute("SELECT count(*) FROM wallets_registry WHERE is_insider = true").fetchone()[0]
confirmed = con.execute("SELECT count(*) FROM wallets_registry WHERE age_status IN ('confirmed', 'gamma', 'alchemy')").fetchone()[0]
unknown = con.execute("SELECT count(*) FROM wallets_registry WHERE age_status = 'unknown'").fetchone()[0]

print(f"Insider trades: {trades:,}")
print(f"Wallets in registry: {wallets:,}")
print(f"  Insiders: {insiders:,}")
print(f"  Confirmed/gamma/alchemy age: {confirmed:,}")
print(f"  Unknown age: {unknown:,}")

# Date range of trades
rng = con.execute("SELECT min(timestamp), max(timestamp) FROM insider_trades").fetchone()
print(f"Insider trade date range: {rng[0]} to {rng[1]}")

# Volume stats
vol = con.execute("SELECT sum(volume_usd), avg(volume_usd), median(volume_usd) FROM insider_trades").fetchone()
print(f"Total volume: ${vol[0]:,.0f}")
print(f"Avg trade: ${vol[1]:,.0f}")
print(f"Median trade: ${vol[2]:,.0f}")

# Age status distribution
statuses = con.execute("SELECT age_status, count(*) FROM wallets_registry GROUP BY age_status").fetchall()
print(f"Age status distribution:")
for s, c in statuses:
    print(f"  {s}: {c:,}")

con.close()
