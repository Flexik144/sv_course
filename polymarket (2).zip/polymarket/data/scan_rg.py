"""Scan row groups, find corrupted ones, extract >= $10K trades from good RGs."""
import pyarrow.parquet as pq
import time, gc

PATH = "C:/hermes/polymarket/data/quant.parquet"
OUT = "C:/hermes/polymarket/data/filtered_10k.parquet"

pf = pq.ParquetFile(PATH)
total_rg = pf.metadata.num_row_groups
print(f"Total: {pf.metadata.num_rows:,} rows in {total_rg} RGs", flush=True)

# Phase 1: identify which RGs might have >= $10K trades
candidate_rgs = []
corrupt_rgs = []
for i in range(total_rg):
    rg = pf.metadata.row_group(i)
    for j in range(rg.num_columns):
        col = rg.column(j)
        if col.path_in_schema == "usd_amount":
            stats = col.statistics
            if stats and stats.max is not None and stats.max >= 10000:
                candidate_rgs.append(i)
            break
    if i % 100 == 0:
        print(f"  Scanning RG {i}/{total_rg}... found {len(candidate_rgs)} candidates so far", flush=True)

print(f"Candidate RGs (max usd_amount >= $10K): {len(candidate_rgs)}", flush=True)

# Phase 2: read each candidate, catch corruption
tables = []
for idx, rg in enumerate(candidate_rgs):
    try:
        tbl = pf.read_row_group(rg, columns=["timestamp","market_id","usd_amount","maker","taker","transaction_hash","price","side"])
        # Filter in memory
        import pyarrow.compute as pc
        mask = pc.greater_equal(tbl.column("usd_amount"), 10000.0)
        if pc.sum(mask).as_py() > 0:
            tables.append(tbl.filter(mask))
        print(f"  [{idx+1}/{len(candidate_rgs)}] RG {rg}: {tbl.num_rows} rows read, kept", flush=True)
    except Exception as e:
        corrupt_rgs.append(rg)
        print(f"  [{idx+1}/{len(candidate_rgs)}] RG {rg}: CORRUPT - {e}", flush=True)

    # Free memory periodically
    if idx > 0 and idx % 50 == 0:
        gc.collect()
        print(f"  GC collected after {idx} RGs", flush=True)

print(f"\nCorrupt RGs: {len(corrupt_rgs)}", flush=True)
if corrupt_rgs:
    print(f"  Corrupt RG list: {corrupt_rgs[:20]}...", flush=True)

if tables:
    import pyarrow as pa
    combined = pa.concat_tables(tables)
    print(f"\nTotal filtered trades >= $10K: {combined.num_rows:,}", flush=True)

    import datetime
    ts = combined.column("timestamp").to_pylist()
    print(f"Date range: {datetime.datetime.fromtimestamp(min(ts))} to {datetime.datetime.fromtimestamp(max(ts))}", flush=True)

    makers = set(combined.column("maker").to_pylist())
    takers = set(combined.column("taker").to_pylist())
    print(f"Unique makers: {len(makers):,}", flush=True)
    print(f"Unique takers: {len(takers):,}", flush=True)
    print(f"Unique wallets: {len(makers|takers):,}", flush=True)

    pq.write_table(combined, OUT)
    import os
    print(f"Saved to {OUT} ({os.path.getsize(OUT)/1024**3:.2f} GB)", flush=True)
else:
    print("No valid trades found!", flush=True)
