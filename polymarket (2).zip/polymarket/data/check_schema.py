"""Check parquet schema."""
import duckdb

con = duckdb.connect()
cols = con.execute("DESCRIBE SELECT * FROM read_parquet('C:/hermes/polymarket/data/quant.parquet')").fetchall()
print("Columns:")
for c in cols:
    print(f"  {c[0]:30s} {c[1]}")
print()

# Sample a few rows
rows = con.execute("SELECT * FROM read_parquet('C:/hermes/polymarket/data/quant.parquet') LIMIT 5").fetchall()
print("Sample rows:")
for r in rows:
    print(f"  {r}")

# Simple count first
cnt = con.execute("SELECT count(*) FROM read_parquet('C:/hermes/polymarket/data/quant.parquet')").fetchone()
print(f"Total rows: {cnt[0]:,}")

# Try min/max one at a time
try:
    min_ts = con.execute("SELECT min(timestamp) FROM read_parquet('C:/hermes/polymarket/data/quant.parquet')").fetchone()
    max_ts = con.execute("SELECT max(timestamp) FROM read_parquet('C:/hermes/polymarket/data/quant.parquet')").fetchone()
    print(f"Timestamp range: {min_ts[0]} to {max_ts[0]}")
    import datetime
    print(f"Date range: {datetime.datetime.fromtimestamp(min_ts[0])} to {datetime.datetime.fromtimestamp(max_ts[0])}")
except Exception as e:
    print(f"Could not get date range: {e}")

# Count >= $10K
big = con.execute("SELECT count(*) FROM read_parquet('C:/hermes/polymarket/data/quant.parquet') WHERE usd_amount >= 10000").fetchone()
print(f"Trades >= $10K: {big[0]:,}")

# Unique maker+taker addresses in >= $10K trades
addrs = con.execute("""
    SELECT count(DISTINCT maker) + count(DISTINCT taker)
    FROM read_parquet('C:/hermes/polymarket/data/quant.parquet')
    WHERE usd_amount >= 10000
""").fetchone()
print(f"Unique wallets (maker+taker) in >= $10K trades: ~{addrs[0]:,}")
