"""Check backup DB for original trades."""
import duckdb

backup_paths = [
    "C:/CursorProjects/polymarket_scanner.duckdb",
    "C:/CursorProjects/polymarket_scanner_backup_20260604_040717.duckdb",
]

for path in backup_paths:
    try:
        con = duckdb.connect(path)
        con.execute("SELECT count(*) FROM insider_trades")
        trades = con.execute("SELECT count(*) FROM insider_trades").fetchone()[0]
        wallets = con.execute("SELECT count(*) FROM wallets_registry").fetchone()[0]
        insiders = con.execute("SELECT count(*) FROM wallets_registry WHERE is_insider = true").fetchone()[0]
        print(f"{path.split('/')[-1]}:")
        print(f"  Trades: {trades}")
        print(f"  Wallets: {wallets}")
        print(f"  Insiders: {insiders}")
        con.close()
    except Exception as e:
        print(f"{path.split('/')[-1]}: Error - {e}")
