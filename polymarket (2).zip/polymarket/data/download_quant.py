#!/usr/bin/env python3
"""
Download quant.parquet from HuggingFace with resume support.
Usage: python download_quant.py
"""

import os
import sys
import time
import requests

REPO = "SII-WANGZJ/Polymarket_data"
FILENAME = "quant.parquet"
OUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_PATH = os.path.join(OUT_DIR, FILENAME)
CHUNK_SIZE = 8 * 1024 * 1024  # 8 MB
TIMEOUT = 60  # seconds per chunk

def sizeof_fmt(num):
    for unit in ("B", "KB", "MB", "GB"):
        if abs(num) < 1024:
            return f"{num:.1f} {unit}"
        num /= 1024
    return f"{num:.1f} TB"

def get_remote_size(url):
    resp = requests.head(url, timeout=30, allow_redirects=True)
    resp.raise_for_status()
    size = resp.headers.get("Content-Length") or resp.headers.get("X-Linked-Size")
    if size:
        return int(size)
    # Try range request
    resp2 = requests.get(url, headers={"Range": "bytes=0-0"}, timeout=30, allow_redirects=True)
    if resp2.status_code in (206, 200):
        cr = resp2.headers.get("Content-Range")
        if cr:
            return int(cr.split("/")[-1])
    return None

def main():
    # Construct download URL
    api_url = f"https://huggingface.co/api/datasets/{REPO}"
    print(f"[INFO] Getting file info from {REPO}...", flush=True)

    # We'll construct the raw URL directly
    download_url = f"https://huggingface.co/datasets/{REPO}/resolve/main/{FILENAME}"

    # Get file size
    total = get_remote_size(download_url)
    if total:
        print(f"[INFO] Remote file size: {sizeof_fmt(total)} ({total:,} bytes)", flush=True)
    else:
        print(f"[WARN] Could not determine remote size", flush=True)

    # Resume check
    start_byte = 0
    if os.path.exists(OUT_PATH):
        local_size = os.path.getsize(OUT_PATH)
        if total and local_size >= total:
            print(f"[INFO] File already fully downloaded: {OUT_PATH}", flush=True)
            return
        if local_size > 0:
            start_byte = local_size
            print(f"[INFO] Resuming from byte {local_size:,} ({sizeof_fmt(local_size)})", flush=True)

    # Download
    headers = {"Range": f"bytes={start_byte}-"} if start_byte > 0 else {}
    mode = "ab" if start_byte > 0 else "wb"

    print(f"[INFO] Starting download...", flush=True)
    start_time = time.time()
    last_log = time.time()

    resp = requests.get(download_url, headers=headers, stream=True, timeout=TIMEOUT, allow_redirects=True)
    resp.raise_for_status()

    with open(OUT_PATH, mode) as f:
        for chunk in resp.iter_content(chunk_size=CHUNK_SIZE):
            if chunk:
                f.write(chunk)
                now = time.time()
                if now - last_log >= 5:
                    elapsed = now - start_time
                    downloaded = os.path.getsize(OUT_PATH)
                    speed = downloaded / elapsed / 1024 / 1024 if elapsed > 0 else 0
                    pct = (downloaded / total * 100) if total else 0
                    eta = (total - downloaded) / (speed * 1024 * 1024) if speed > 0 else 0
                    eta_str = f"{eta/60:.0f}min" if eta < 3600 else f"{eta/3600:.1f}h"
                    print(f"  [{pct:.1f}%] {sizeof_fmt(downloaded)} / {sizeof_fmt(total)} @ {speed:.2f} MB/s, ETA: {eta_str}", flush=True)
                    last_log = now

    elapsed = time.time() - start_time
    final_size = os.path.getsize(OUT_PATH)
    speed = final_size / elapsed / 1024 / 1024 if elapsed > 0 else 0
    print(f"[DONE] {sizeof_fmt(final_size)} downloaded in {elapsed/60:.1f}min ({speed:.2f} MB/s)", flush=True)
    print(f"[DONE] Saved to: {OUT_PATH}", flush=True)

if __name__ == "__main__":
    main()
