#!/usr/bin/env python3
"""Download quant.parquet from scratch (no resume) with integrity check."""
import os, sys, time, requests

REPO = "SII-WANGZJ/Polymarket_data"
FILENAME = "quant.parquet"
OUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_PATH = os.path.join(OUT_DIR, FILENAME)
CHUNK_SIZE = 8 * 1024 * 1024
TIMEOUT = 120

DOWNLOAD_URL = f"https://huggingface.co/datasets/{REPO}/resolve/main/{FILENAME}"

def sizeof_fmt(num):
    for unit in ("B", "KB", "MB", "GB"):
        if abs(num) < 1024:
            return f"{num:.1f} {unit}"
        num /= 1024
    return f"{num:.1f} TB"

# Get remote size
resp = requests.head(DOWNLOAD_URL, timeout=30, allow_redirects=True)
resp.raise_for_status()
total = int(resp.headers.get("Content-Length", 0))
print(f"[INFO] Remote size: {sizeof_fmt(total)} ({total:,} bytes)", flush=True)

# Delete partial file
if os.path.exists(OUT_PATH):
    old_size = os.path.getsize(OUT_PATH)
    print(f"[INFO] Removing partial file ({sizeof_fmt(old_size)})...", flush=True)
    os.remove(OUT_PATH)

# Fresh download
print(f"[INFO] Downloading {FILENAME} from scratch...", flush=True)
start_time = time.time()
last_log = time.time()

resp = requests.get(DOWNLOAD_URL, stream=True, timeout=TIMEOUT, allow_redirects=True)
resp.raise_for_status()

with open(OUT_PATH, "wb") as f:
    for chunk in resp.iter_content(chunk_size=CHUNK_SIZE):
        if chunk:
            f.write(chunk)
            f.flush()
            os.fsync(f.fileno())
            now = time.time()
            if now - last_log >= 10:
                elapsed = now - start_time
                downloaded = os.path.getsize(OUT_PATH)
                speed = downloaded / elapsed / 1024 / 1024
                pct = downloaded / total * 100 if total else 0
                eta = (total - downloaded) / (speed * 1024 * 1024) if speed > 0 else 0
                print(f"  [{pct:.1f}%] {sizeof_fmt(downloaded)} / {sizeof_fmt(total)} @ {speed:.2f} MB/s, ETA: {eta/60:.0f}min", flush=True)
                last_log = now

elapsed = time.time() - start_time
final = os.path.getsize(OUT_PATH)
speed = final / elapsed / 1024 / 1024
print(f"[DONE] {sizeof_fmt(final)} in {elapsed/60:.1f}min ({speed:.2f} MB/s)", flush=True)

# Quick integrity: check Parquet magic bytes
with open(OUT_PATH, "rb") as f:
    magic = f.read(4)
    if magic != b"PAR1":
        print("[ERROR] Invalid Parquet magic bytes - file corrupted!", flush=True)
        sys.exit(1)
    f.seek(-4, 2)
    magic_end = f.read(4)
    if magic_end != b"PAR1":
        print("[ERROR] Invalid Parquet footer magic - file truncated?", flush=True)
        sys.exit(1)
print("[OK] Parquet magic bytes verified (PAR1 at start and end)", flush=True)
print(f"[DONE] Saved to: {OUT_PATH}", flush=True)
