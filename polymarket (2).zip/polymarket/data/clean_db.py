"""Clean the test data from retro processor runs."""
import duckdb

con = duckdb.connect("C:/hermes/polymarket/polymarket_scanner.duckdb")

# Check current state
r = con.execute("SELECT count(*) FROM insider_trades").fetchone()
print(f"Insider trades before: {r[0]}")

r = con.execute("SELECT count(*), age_status FROM wallets_registry GROUP BY age_status").fetchall()
print(f"Wallets by status before:")
for cnt, status in r:
    print(f"  {status}: {cnt}")

# Recreate insider_trades table (keep only original trades without ':')
con.execute("CREATE TABLE insider_trades_new AS SELECT * FROM insider_trades WHERE trade_id NOT LIKE '%:%'")
r = con.execute("SELECT count(*) FROM insider_trades_new").fetchone()
print(f"Trades kept: {r[0]}")

con.execute("DROP TABLE insider_trades")
con.execute("ALTER TABLE insider_trades_new RENAME TO insider_trades")

# Delete retro-processed wallets and trades
con.execute("DELETE FROM wallets_registry WHERE age_status NOT IN ('confirmed', 'unknown')")
r = con.execute("SELECT count(*) FROM wallets_registry").fetchone()
print(f"Wallets after cleanup: {r[0]}")

con.close()
print("Done")
