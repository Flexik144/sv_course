"""Compare wallets from filtered_10k.parquet with existing DB."""
import duckdb

parquet_path = "C:/hermes/polymarket/data/filtered_10k.parquet"
db_path = "C:/hermes/polymarket/polymarket_scanner.duckdb"

# Load wallets from parquet
con = duckdb.connect()
parquet_addrs = con.execute(f"""
    SELECT DISTINCT LOWER(maker) FROM read_parquet('{parquet_path}')
    UNION
    SELECT DISTINCT LOWER(taker) FROM read_parquet('{parquet_path}')
""").fetchall()
all_wallets = set(r[0] for r in parquet_addrs)
print(f"Unique wallets from parquet: {len(all_wallets):,}")

# Load from our DB
con2 = duckdb.connect(db_path)
known = con2.execute("SELECT LOWER(wallet_address) FROM wallets_registry").fetchall()
known_set = set(r[0] for r in known)
print(f"Known wallets in DB: {len(known):,}")

# New vs existing
new = all_wallets - known_set
existing = all_wallets & known_set
print(f"New wallets to check: {len(new):,}")
print(f"Already in DB: {len(existing):,}")

# Check how many new wallets are in which time range
# Also check insider count among existing
insiders_count = con2.execute("SELECT COUNT(*) FROM wallets_registry WHERE is_insider = true").fetchone()
print(f"Current insiders in DB: {insiders_count[0]}")
