export type Market = { id: string; question: string; event: string; slug: string; image: string; category: string; outcomes: { name: string; probability: number }[]; volume: number; volume24h: number; liquidity: number; endDate: string; active: boolean; change: number; description: string };
export type MarketData = { markets: Market[]; updatedAt: string; source: 'live' | 'cache'; error?: string };
export type SavedDataset = { id: number; name: string; markets: Market[]; createdAt: string };
export type LoadRun = { id: number; count: number; status: string; createdAt: string };
