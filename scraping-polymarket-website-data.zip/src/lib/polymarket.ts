import { db } from '@/db';
import { snapshots, loadRuns } from '@/db/schema';
import { desc } from 'drizzle-orm';
import type { Market, MarketData } from './types';
type Raw = Record<string, unknown>;
const num = (value: unknown) => Number(value) || 0;
function array(value: unknown): string[] { try { const parsed = typeof value === 'string' ? JSON.parse(value) : value; return Array.isArray(parsed) ? parsed.map(String) : []; } catch { return []; } }
function category(tags: Raw[]): string {
 const names = tags.map(t => String(t.label).toLowerCase()).join(' ');
 if (/sport|soccer|nba|nfl|baseball|football|tennis|esport|ufc|cricket/.test(names)) return 'Спорт';
 if (/crypto|bitcoin|ethereum|solana/.test(names)) return 'Криптовалюты';
 if (/econom|financ|fed |rates|business|stocks/.test(names)) return 'Экономика';
 if (/politic|election|trump|geopolit|world|iran|ukraine/.test(names)) return 'Политика';
 if (/tech|science|ai |openai/.test(names)) return 'Технологии';
 if (/culture|music|movie|entertainment/.test(names)) return 'Культура';
 return 'Другое';
}
export async function getMarkets(refresh = false): Promise<MarketData> {
 let cached: typeof snapshots.$inferSelect | undefined;
 try { [cached] = await db.select().from(snapshots).orderBy(desc(snapshots.createdAt)).limit(1); } catch { /* Database may still be bootstrapping. */ }
 if (!refresh && cached && Date.now() - cached.createdAt.getTime() < 300000) return { markets: cached.markets, updatedAt: cached.createdAt.toISOString(), source: 'cache' };
 try {
 const response = await fetch('https://gamma-api.polymarket.com/events?active=true&closed=false&limit=100&order=volume24hr&ascending=false', { cache: 'no-store', signal: AbortSignal.timeout(20000) });
 if (!response.ok) throw new Error(`Gamma API: ${response.status}`);
 const events = await response.json() as Raw[];
 if (!Array.isArray(events)) throw new Error('Некорректный ответ источника');
 const markets: Market[] = events.flatMap(event => ((event.markets || []) as Raw[]).filter(m => m.active && !m.closed).map(m => {
 const prices = array(m.outcomePrices);
 return { id: String(m.id), question: String(m.question || event.title), event: String(event.title || ''), slug: String(event.slug || m.slug), image: String(m.image || event.image || ''), category: category((event.tags || []) as Raw[]), outcomes: array(m.outcomes).map((name, i) => ({ name, probability: num(prices[i]) * 100 })), volume: num(m.volume), volume24h: num(m.volume24hr), liquidity: num(m.liquidity), endDate: String(m.endDate || event.endDate || ''), active: Boolean(m.active) && !m.closed, change: num(m.oneDayPriceChange) * 100, description: String(m.description || event.description || '') };
 })).sort((a,b) => b.volume24h - a.volume24h);
 const unique = Array.from(new Map(markets.map(m => [m.id,m])).values());
 const updatedAt = new Date().toISOString();
 try { await db.transaction(async tx => { await tx.insert(snapshots).values({ markets: unique }); await tx.insert(loadRuns).values({ count: unique.length, status: 'success' }); }); } catch (e) { console.error('Snapshot persistence failed', e); }
 return { markets: unique, updatedAt, source: 'live' };
 } catch (e) {
 console.error('Gamma API fetch failed', e);
 if (cached) return { markets: cached.markets, updatedAt: cached.createdAt.toISOString(), source: 'cache', error: 'Источник временно недоступен. Показан последний сохранённый снимок.' };
 return { markets: [], updatedAt: '', source: 'cache', error: 'Не удалось подключиться к Polymarket. Попробуйте обновить данные.' };
 }
}
