import Dashboard from '@/components/dashboard';
import { getMarkets } from '@/lib/polymarket';
export const dynamic = 'force-dynamic';
export default async function Page() { const data = await getMarkets(); return <Dashboard initialData={data} />; }
