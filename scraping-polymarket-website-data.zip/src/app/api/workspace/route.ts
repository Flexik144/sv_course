import { db } from '@/db';
import { datasets, favorites, loadRuns, snapshots } from '@/db/schema';
import { desc, eq } from 'drizzle-orm';
export async function GET() {
 try { const [saved, starred, runs] = await Promise.all([db.select().from(datasets).orderBy(desc(datasets.createdAt)), db.select().from(favorites), db.select().from(loadRuns).orderBy(desc(loadRuns.createdAt)).limit(50)]); return Response.json({ datasets: saved, favorites: starred.map(x => x.marketId), runs }); }
 catch { return Response.json({ error: 'Не удалось загрузить рабочее пространство' }, { status: 500 }); }
}
export async function POST(request: Request) {
 try { const body = await request.json();
 if (body.action === 'favorite' && typeof body.id === 'string') { if (body.active) await db.insert(favorites).values({ marketId: body.id }).onConflictDoNothing(); else await db.delete(favorites).where(eq(favorites.marketId, body.id)); return Response.json({ ok: true }); }
 if (body.action === 'save' && typeof body.name === 'string' && body.name.trim() && Array.isArray(body.ids)) { const [snapshot] = await db.select().from(snapshots).orderBy(desc(snapshots.createdAt)).limit(1); if (!snapshot) return Response.json({ error: 'Сначала обновите данные' }, { status: 400 }); const ids = new Set(body.ids); const markets = snapshot.markets.filter(m => ids.has(m.id)); if (!markets.length) return Response.json({ error: 'Выборка пуста' }, { status: 400 }); const [saved] = await db.insert(datasets).values({ name: body.name.trim().slice(0,100), markets }).returning(); return Response.json(saved); }
 if (body.action === 'delete' && Number.isInteger(body.id)) { await db.delete(datasets).where(eq(datasets.id, body.id)); return Response.json({ ok: true }); }
 return Response.json({ error: 'Некорректный запрос' }, { status: 400 });
 } catch { return Response.json({ error: 'Не удалось сохранить изменения' }, { status: 500 }); }
}
