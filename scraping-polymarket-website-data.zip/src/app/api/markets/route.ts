import { getMarkets } from '@/lib/polymarket';
export const dynamic = 'force-dynamic';
export async function GET(request: Request) { const data = await getMarkets(new URL(request.url).searchParams.get('refresh') === 'true'); return Response.json(data); }
