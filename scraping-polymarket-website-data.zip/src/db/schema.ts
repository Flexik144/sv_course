import { pgTable, serial, text, timestamp, jsonb, integer } from 'drizzle-orm/pg-core';
import type { Market } from '@/lib/types';
export const snapshots = pgTable('market_snapshots', { id: serial('id').primaryKey(), markets: jsonb('markets').$type<Market[]>().notNull(), createdAt: timestamp('created_at').defaultNow().notNull() });
export const favorites = pgTable('market_favorites', { marketId: text('market_id').primaryKey(), createdAt: timestamp('created_at').defaultNow().notNull() });
export const datasets = pgTable('market_datasets', { id: serial('id').primaryKey(), name: text('name').notNull(), markets: jsonb('markets').$type<Market[]>().notNull(), createdAt: timestamp('created_at').defaultNow().notNull() });
export const loadRuns = pgTable('market_load_runs', { id: serial('id').primaryKey(), count: integer('count').notNull(), status: text('status').notNull(), createdAt: timestamp('created_at').defaultNow().notNull() });
